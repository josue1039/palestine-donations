<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/../vendor/autoload.php';

function sendDonationReceipt($donationId) {
    global $pdo;
    
    // Récupérer les détails du don
    $stmt = $pdo->prepare("
        SELECT * FROM donations 
        WHERE id = ? AND status = 'completed'
    ");
    $stmt->execute([$donationId]);
    $donation = $stmt->fetch();
    
    if (!$donation) {
        return false;
    }
    
    $mail = new PHPMailer(true);
    
    try {
        // Configuration SMTP
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com'; // Ou votre serveur SMTP
        $mail->SMTPAuth   = true;
        $mail->Username   = 'votre-email@gmail.com'; // Votre email
        $mail->Password   = 'votre-mot-de-passe-app'; // Mot de passe d'application
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;
        
        // Expéditeur et destinataire
        $mail->setFrom('noreply@najamrelief.org', 'Najam Relief');
        $mail->addAddress($donation['email'], $donation['donor_name']);
        
        // Contenu de l'email
        $mail->isHTML(true);
        $mail->CharSet = 'UTF-8';
        $mail->Subject = 'Reçu de don - Merci pour votre générosité';
        
        $donationType = $donation['is_monthly'] ? 'don mensuel' : 'don unique';
        $amountDisplay = formatCurrency($donation['amount'], $donation['currency']);
        
        $mail->Body = generateReceiptHTML($donation, $donationType, $amountDisplay);
        $mail->AltBody = generateReceiptText($donation, $donationType, $amountDisplay);
        
        $mail->send();
        return true;
        
    } catch (Exception $e) {
        error_log("Erreur envoi email: {$mail->ErrorInfo}");
        return false;
    }
}

function generateReceiptHTML($donation, $donationType, $amountDisplay) {
    $date = date('d/m/Y à H:i', strtotime($donation['created_at']));
    
    return "
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='UTF-8'>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #0ea5e9; color: white; padding: 20px; text-align: center; }
            .content { padding: 20px; background: #f9f9f9; }
            .receipt-box { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; }
            .amount { font-size: 24px; font-weight: bold; color: #0ea5e9; }
            .footer { text-align: center; padding: 20px; font-size: 12px; color: #666; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1>🤲 Merci pour votre don !</h1>
            </div>
            
            <div class='content'>
                <p>Cher/Chère {$donation['donor_name']},</p>
                
                <p>Nous vous remercions sincèrement pour votre {$donationType} qui permettra d'apporter de l'aide aux familles palestiniennes dans le besoin.</p>
                
                <div class='receipt-box'>
                    <h3>📋 Détails de votre don</h3>
                    <p><strong>Montant :</strong> <span class='amount'>{$amountDisplay}</span></p>
                    <p><strong>Type :</strong> " . ($donation['is_monthly'] ? 'Don mensuel récurrent' : 'Don unique') . "</p>
                    <p><strong>Date :</strong> {$date}</p>
                    <p><strong>ID de transaction :</strong> {$donation['transaction_id']}</p>
                    " . ($donation['comment'] ? "<p><strong>Commentaire :</strong> {$donation['comment']}</p>" : "") . "
                </div>
                
                <div class='receipt-box'>
                    <h3>💝 Impact de votre don</h3>
                    <p>Grâce à votre générosité :</p>
                    <ul>
                        <li>🍽️ <strong>" . round($donation['amount_usd'] * 10) . " repas</strong> pourront être fournis</li>
                        <li>👨‍👩‍👧‍👦 <strong>" . round($donation['amount_usd'] * 3) . " familles</strong> recevront de l'aide</li>
                        <li>❤️ Vous apportez <strong>espoir et dignité</strong> à ceux qui en ont le plus besoin</li>
                    </ul>
                </div>
                
                <p><strong>Ce reçu constitue votre justificatif officiel pour la déduction fiscale.</strong></p>
                
                <p>Que Dieu vous bénisse pour votre générosité et votre solidarité.</p>
                
                <p>Avec toute notre gratitude,<br>
                <strong>L'équipe Najam Relief</strong></p>
            </div>
            
            <div class='footer'>
                <p>Najam Relief - Organisation humanitaire<br>
                Email: contact@najamrelief.org | Web: www.najamrelief.org</p>
                <p>Ce don est déductible des impôts selon la réglementation en vigueur.</p>
            </div>
        </div>
    </body>
    </html>
    ";
}

function generateReceiptText($donation, $donationType, $amountDisplay) {
    $date = date('d/m/Y à H:i', strtotime($donation['created_at']));
    
    return "
MERCI POUR VOTRE DON !

Cher/Chère {$donation['donor_name']},

Nous vous remercions sincèrement pour votre {$donationType} qui permettra d'apporter de l'aide aux familles palestiniennes dans le besoin.

DÉTAILS DE VOTRE DON
Montant : {$amountDisplay}
Type : " . ($donation['is_monthly'] ? 'Don mensuel récurrent' : 'Don unique') . "
Date : {$date}
ID de transaction : {$donation['transaction_id']}
" . ($donation['comment'] ? "Commentaire : {$donation['comment']}" : "") . "

IMPACT DE VOTRE DON
Grâce à votre générosité :
- " . round($donation['amount_usd'] * 10) . " repas pourront être fournis
- " . round($donation['amount_usd'] * 3) . " familles recevront de l'aide
- Vous apportez espoir et dignité à ceux qui en ont le plus besoin

Ce reçu constitue votre justificatif officiel pour la déduction fiscale.

Que Dieu vous bénisse pour votre générosité et votre solidarité.

Avec toute notre gratitude,
L'équipe Najam Relief

---
Najam Relief - Organisation humanitaire
Email: contact@najamrelief.org | Web: www.najamrelief.org
Ce don est déductible des impôts selon la réglementation en vigueur.
    ";
}
?>