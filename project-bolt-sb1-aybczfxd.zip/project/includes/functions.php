<?php
function getDonationStats($pdo) {
    $stmt = $pdo->query("
        SELECT 
            COALESCE(SUM(amount_usd), 0) as total_raised,
            COUNT(*) as total_donations,
            COUNT(DISTINCT country) as countries,
            COALESCE(SUM(amount_usd) * 3, 0) as families_helped,
            COALESCE(SUM(amount_usd) * 10, 0) as meals_provided
        FROM donations 
        WHERE status = 'completed'
    ");
    
    $stats = $stmt->fetch();
    $stats['goal'] = 1500000; // Goal amount in USD
    
    return $stats;
}

function getRecentDonations($pdo, $limit = 8) {
    $stmt = $pdo->prepare("
        SELECT 
            donor_name,
            amount,
            currency,
            amount_usd,
            is_monthly,
            country,
            city,
            created_at,
            CASE 
                WHEN country = 'France' THEN '🇫🇷'
                WHEN country = 'United States' THEN '🇺🇸'
                WHEN country = 'United Kingdom' THEN '🇬🇧'
                WHEN country = 'Germany' THEN '🇩🇪'
                WHEN country = 'Spain' THEN '🇪🇸'
                WHEN country = 'Italy' THEN '🇮🇹'
                WHEN country = 'Morocco' THEN '🇲🇦'
                WHEN country = 'Algeria' THEN '🇩🇿'
                WHEN country = 'Tunisia' THEN '🇹🇳'
                WHEN country = 'Canada' THEN '🇨🇦'
                WHEN country = 'Australia' THEN '🇦🇺'
                WHEN country = 'Netherlands' THEN '🇳🇱'
                WHEN country = 'Belgium' THEN '🇧🇪'
                WHEN country = 'Switzerland' THEN '🇨🇭'
                WHEN country = 'Sweden' THEN '🇸🇪'
                WHEN country = 'Norway' THEN '🇳🇴'
                WHEN country = 'Denmark' THEN '🇩🇰'
                WHEN country = 'Japan' THEN '🇯🇵'
                WHEN country = 'South Korea' THEN '🇰🇷'
                WHEN country = 'Singapore' THEN '🇸🇬'
                WHEN country = 'UAE' THEN '🇦🇪'
                WHEN country = 'Saudi Arabia' THEN '🇸🇦'
                WHEN country = 'Qatar' THEN '🇶🇦'
                WHEN country = 'Kuwait' THEN '🇰🇼'
                WHEN country = 'Turkey' THEN '🇹🇷'
                WHEN country = 'Egypt' THEN '🇪🇬'
                WHEN country = 'Jordan' THEN '🇯🇴'
                WHEN country = 'Lebanon' THEN '🇱🇧'
                WHEN country = 'Pakistan' THEN '🇵🇰'
                WHEN country = 'India' THEN '🇮🇳'
                WHEN country = 'Bangladesh' THEN '🇧🇩'
                WHEN country = 'Indonesia' THEN '🇮🇩'
                WHEN country = 'Malaysia' THEN '🇲🇾'
                WHEN country = 'Thailand' THEN '🇹🇭'
                WHEN country = 'Philippines' THEN '🇵🇭'
                WHEN country = 'Vietnam' THEN '🇻🇳'
                WHEN country = 'Brazil' THEN '🇧🇷'
                WHEN country = 'Mexico' THEN '🇲🇽'
                WHEN country = 'Argentina' THEN '🇦🇷'
                WHEN country = 'Chile' THEN '🇨🇱'
                WHEN country = 'Colombia' THEN '🇨🇴'
                WHEN country = 'South Africa' THEN '🇿🇦'
                WHEN country = 'Nigeria' THEN '🇳🇬'
                WHEN country = 'Kenya' THEN '🇰🇪'
                WHEN country = 'Tanzania' THEN '🇹🇿'
                ELSE '🌍'
            END as country_flag
        FROM donations 
        WHERE status = 'completed'
        ORDER BY created_at DESC 
        LIMIT ?
    ");
    
    $stmt->execute([$limit]);
    $donations = $stmt->fetchAll();
    
    foreach ($donations as &$donation) {
        $donation['amount_display'] = formatCurrency($donation['amount'], $donation['currency']);
        $donation['donation_type'] = $donation['is_monthly'] ? 'a fait son don régulier' : 'a fait un don unique';
        $donation['location'] = $donation['city'] ? $donation['city'] . ', ' . $donation['country'] : $donation['country'];
    }
    
    return $donations;
}

function formatCurrency($amount, $currency = 'USD') {
    $symbols = [
        'EUR' => '€', 'USD' => '$', 'GBP' => '£', 'CAD' => 'C$', 'AUD' => 'A$', 
        'CHF' => 'CHF', 'SEK' => 'kr', 'NOK' => 'kr', 'DKK' => 'kr',
        'JPY' => '¥', 'CNY' => '¥', 'KRW' => '₩', 'SGD' => 'S$', 'HKD' => 'HK$',
        'NZD' => 'NZ$', 'MXN' => '$', 'BRL' => 'R$', 'ARS' => '$', 'CLP' => '$',
        'COP' => '$', 'PEN' => 'S/', 'UYU' => '$U', 'ZAR' => 'R', 'EGP' => '£',
        'MAD' => 'DH', 'TND' => 'DT', 'DZD' => 'DA', 'SAR' => 'SR', 'AED' => 'AED',
        'QAR' => 'QR', 'KWD' => 'KD', 'BHD' => 'BD', 'OMR' => 'OMR', 'JOD' => 'JD',
        'LBP' => 'LL', 'ILS' => '₪', 'TRY' => '₺', 'IRR' => '﷼', 'PKR' => '₨',
        'INR' => '₹', 'BDT' => '৳', 'LKR' => '₨', 'NPR' => '₨', 'AFN' => '؋',
        'MYR' => 'RM', 'THB' => '฿', 'IDR' => 'Rp', 'PHP' => '₱', 'VND' => '₫',
        'RUB' => '₽', 'UAH' => '₴', 'PLN' => 'zł', 'CZK' => 'Kč', 'HUF' => 'Ft',
        'RON' => 'lei', 'BGN' => 'лв', 'HRK' => 'kn', 'RSD' => 'дин', 'BAM' => 'KM',
        'MKD' => 'ден', 'ALL' => 'L', 'NGN' => '₦', 'GHS' => '₵', 'KES' => 'KSh',
        'UGX' => 'USh', 'TZS' => 'TSh', 'ETB' => 'Br', 'XOF' => 'CFA', 'XAF' => 'FCFA',
        'MUR' => '₨', 'SCR' => '₨'
    ];
    
    $symbol = $symbols[$currency] ?? '$';
    return number_format($amount, 2) . ' ' . $symbol;
}

function processDonation($data) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO donations (
                donor_name, email, phone, amount, currency, amount_usd, 
                is_monthly, is_dedicated, comment, country, city, 
                payment_method, transaction_id, status, created_at
            ) VALUES (
                ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'completed', NOW()
            )
        ");
        
        $stmt->execute([
            $data['donor_name'],
            $data['email'],
            $data['phone'],
            $data['amount'],
            $data['currency'],
            $data['amount_usd'],
            $data['is_monthly'] ? 1 : 0,
            $data['is_dedicated'] ? 1 : 0,
            $data['comment'],
            $data['country'],
            $data['city'],
            $data['payment_method'],
            $data['transaction_id']
        ]);
        
        return $pdo->lastInsertId();
    } catch (PDOException $e) {
        error_log("Donation processing error: " . $e->getMessage());
        return false;
    }
}

function sendDonationReceipt($donationId) {
    // Implementation for sending email receipt
    // This would integrate with your email service
    return true;
}

function getCurrencyExchangeRate($from, $to = 'USD') {
    // Mock exchange rates - in production, use a real API
    $rates = [
        'EUR' => 1.10, 'USD' => 1.00, 'GBP' => 1.25, 'CAD' => 0.75, 'AUD' => 0.68,
        'CHF' => 1.08, 'SEK' => 0.095, 'NOK' => 0.092, 'DKK' => 0.148,
        'JPY' => 0.0067, 'CNY' => 0.14, 'KRW' => 0.00075, 'SGD' => 0.74, 'HKD' => 0.13,
        'NZD' => 0.62, 'MXN' => 0.058, 'BRL' => 0.20, 'ARS' => 0.0011, 'CLP' => 0.0011,
        'COP' => 0.00025, 'PEN' => 0.27, 'UYU' => 0.026, 'ZAR' => 0.055, 'EGP' => 0.032,
        'MAD' => 0.10, 'TND' => 0.32, 'DZD' => 0.0075, 'SAR' => 0.27, 'AED' => 0.27,
        'QAR' => 0.27, 'KWD' => 3.30, 'BHD' => 2.65, 'OMR' => 2.60, 'JOD' => 1.41,
        'LBP' => 0.000066, 'ILS' => 0.27, 'TRY' => 0.034, 'IRR' => 0.000024, 'PKR' => 0.0036,
        'INR' => 0.012, 'BDT' => 0.0093, 'LKR' => 0.0031, 'NPR' => 0.0075, 'AFN' => 0.011,
        'MYR' => 0.22, 'THB' => 0.028, 'IDR' => 0.000065, 'PHP' => 0.018, 'VND' => 0.000041,
        'RUB' => 0.011, 'UAH' => 0.024, 'PLN' => 0.25, 'CZK' => 0.044, 'HUF' => 0.0027,
        'RON' => 0.22, 'BGN' => 0.56, 'HRK' => 0.15, 'RSD' => 0.0093, 'BAM' => 0.56,
        'MKD' => 0.018, 'ALL' => 0.011, 'NGN' => 0.00065, 'GHS' => 0.083, 'KES' => 0.0077,
        'UGX' => 0.00027, 'TZS' => 0.00043, 'ETB' => 0.018, 'XOF' => 0.0017, 'XAF' => 0.0017,
        'MUR' => 0.022, 'SCR' => 0.074
    ];
    
    return $rates[$from] ?? 1.00;
}
?>