<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Gérer les requêtes OPTIONS pour CORS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once '../config/database.php';
require_once '../config/stripe.php';
require_once '../includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON']);
    exit;
}

// Validation des champs requis
$required = ['amount', 'currency', 'firstName', 'lastName', 'email'];
foreach ($required as $field) {
    if (empty($input[$field])) {
        http_response_code(400);
        echo json_encode(['error' => "Field $field is required"]);
        exit;
    }
}

try {
    // Calculer le montant avec les frais si demandé
    $amount = floatval($input['amount']);
    $currency = strtolower($input['currency']);
    
    if (isset($input['coverFees']) && $input['coverFees']) {
        $fee = $amount * 0.029 + 0.30; // 2.9% + 0.30€ pour Stripe
        $amount += $fee;
    }
    
    // Convertir en centimes pour Stripe
    $amountCents = intval($amount * 100);
    
    // Métadonnées pour le paiement
    $metadata = [
        'donor_name' => $input['firstName'] . ' ' . $input['lastName'],
        'donor_email' => $input['email'],
        'is_monthly' => isset($input['isMonthly']) && $input['isMonthly'] ? 'true' : 'false',
        'is_dedicated' => isset($input['isDedicated']) && $input['isDedicated'] ? 'true' : 'false',
        'comment' => $input['comment'] ?? '',
        'country' => $input['country'] ?? '',
        'city' => $input['city'] ?? '',
        'phone' => ($input['countryCode'] ?? '') . ($input['phone'] ?? ''),
        'cover_fees' => isset($input['coverFees']) && $input['coverFees'] ? 'true' : 'false'
    ];
    
    // Si c'est un don mensuel, créer un abonnement
    if (isset($input['isMonthly']) && $input['isMonthly']) {
        // Créer le client Stripe
        $customer = \Stripe\Customer::create([
            'email' => $input['email'],
            'name' => $input['firstName'] . ' ' . $input['lastName'],
            'metadata' => [
                'country' => $input['country'] ?? '',
                'city' => $input['city'] ?? '',
                'phone' => ($input['countryCode'] ?? '') . ($input['phone'] ?? '')
            ]
        ]);
        
        // Créer le produit et le prix pour l'abonnement
        $product = \Stripe\Product::create([
            'name' => 'Don mensuel - Aide humanitaire Palestine',
            'description' => 'Don mensuel récurrent pour l\'aide humanitaire en Palestine'
        ]);
        
        $price = \Stripe\Price::create([
            'unit_amount' => $amountCents,
            'currency' => $currency,
            'recurring' => ['interval' => 'month'],
            'product' => $product->id,
        ]);
        
        // Créer l'abonnement
        $subscription = \Stripe\Subscription::create([
            'customer' => $customer->id,
            'items' => [['price' => $price->id]],
            'payment_behavior' => 'default_incomplete',
            'payment_settings' => ['save_default_payment_method' => 'on_subscription'],
            'expand' => ['latest_invoice.payment_intent'],
            'metadata' => $metadata
        ]);
        
        echo json_encode([
            'success' => true,
            'client_secret' => $subscription->latest_invoice->payment_intent->client_secret,
            'subscription_id' => $subscription->id,
            'customer_id' => $customer->id,
            'type' => 'subscription'
        ]);
    } else {
        // Créer un PaymentIntent pour un don unique
        $paymentIntent = \Stripe\PaymentIntent::create([
            'amount' => $amountCents,
            'currency' => $currency,
            'payment_method_types' => ['card'],
            'metadata' => $metadata,
            'receipt_email' => $input['email'],
            'description' => 'Don pour l\'aide humanitaire en Palestine'
        ]);
        
        echo json_encode([
            'success' => true,
            'client_secret' => $paymentIntent->client_secret,
            'payment_intent_id' => $paymentIntent->id,
            'type' => 'one_time'
        ]);
    }
    
} catch (\Stripe\Exception\CardException $e) {
    http_response_code(400);
    echo json_encode(['error' => $e->getError()->message]);
} catch (\Stripe\Exception\RateLimitException $e) {
    http_response_code(429);
    echo json_encode(['error' => 'Trop de requêtes, veuillez réessayer plus tard']);
} catch (\Stripe\Exception\InvalidRequestException $e) {
    http_response_code(400);
    echo json_encode(['error' => 'Requête invalide: ' . $e->getMessage()]);
} catch (\Stripe\Exception\AuthenticationException $e) {
    http_response_code(401);
    echo json_encode(['error' => 'Erreur d\'authentification Stripe']);
} catch (\Stripe\Exception\ApiConnectionException $e) {
    http_response_code(502);
    echo json_encode(['error' => 'Erreur de connexion au service de paiement']);
} catch (\Stripe\Exception\ApiErrorException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erreur du service de paiement: ' . $e->getMessage()]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erreur interne du serveur: ' . $e->getMessage()]);
}
?>