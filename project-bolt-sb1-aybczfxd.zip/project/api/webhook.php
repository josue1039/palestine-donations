<?php
require_once '../config/database.php';
require_once '../config/stripe.php';
require_once '../includes/functions.php';

// Récupérer le payload et la signature
$payload = @file_get_contents('php://input');
$sig_header = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';

try {
    // Vérifier la signature du webhook
    $event = \Stripe\Webhook::constructEvent(
        $payload, $sig_header, STRIPE_WEBHOOK_SECRET
    );
} catch(\UnexpectedValueException $e) {
    // Payload invalide
    http_response_code(400);
    exit();
} catch(\Stripe\Exception\SignatureVerificationException $e) {
    // Signature invalide
    http_response_code(400);
    exit();
}

// Traiter l'événement
switch ($event['type']) {
    case 'payment_intent.succeeded':
        $paymentIntent = $event['data']['object'];
        handleSuccessfulPayment($paymentIntent, $pdo);
        break;
        
    case 'invoice.payment_succeeded':
        $invoice = $event['data']['object'];
        if ($invoice['billing_reason'] == 'subscription_cycle') {
            handleSuccessfulSubscriptionPayment($invoice, $pdo);
        }
        break;
        
    case 'customer.subscription.deleted':
        $subscription = $event['data']['object'];
        handleCancelledSubscription($subscription, $pdo);
        break;
        
    default:
        // Événement non géré
        break;
}

http_response_code(200);

function handleSuccessfulPayment($paymentIntent, $pdo) {
    $metadata = $paymentIntent['metadata'];
    
    // Convertir le montant de centimes vers l'unité normale
    $amount = $paymentIntent['amount'] / 100;
    $currency = strtoupper($paymentIntent['currency']);
    
    // Convertir en USD pour les statistiques
    $exchangeRate = getCurrencyExchangeRate($currency);
    $amountUsd = $amount * $exchangeRate;
    
    // Préparer les données du don
    $donationData = [
        'donor_name' => $metadata['donor_name'],
        'email' => $paymentIntent['receipt_email'],
        'phone' => $metadata['phone'] ?? '',
        'amount' => $amount,
        'currency' => $currency,
        'amount_usd' => $amountUsd,
        'is_monthly' => $metadata['is_monthly'] === 'true',
        'is_dedicated' => $metadata['is_dedicated'] === 'true',
        'comment' => $metadata['comment'] ?? '',
        'country' => $metadata['country'] ?? 'Unknown',
        'city' => $metadata['city'] ?? '',
        'payment_method' => 'card',
        'transaction_id' => $paymentIntent['id'],
        'stripe_payment_intent_id' => $paymentIntent['id']
    ];
    
    // Enregistrer le don
    $donationId = processDonation($donationData);
    
    if ($donationId) {
        // Envoyer l'email de reçu
        sendDonationReceipt($donationId);
        
        // Log pour debug
        error_log("Don traité avec succès: ID $donationId, Montant: $amount $currency");
    }
}

function handleSuccessfulSubscriptionPayment($invoice, $pdo) {
    // Traiter les paiements d'abonnement récurrents
    $subscription = \Stripe\Subscription::retrieve($invoice['subscription']);
    $customer = \Stripe\Customer::retrieve($invoice['customer']);
    
    $amount = $invoice['amount_paid'] / 100;
    $currency = strtoupper($invoice['currency']);
    $exchangeRate = getCurrencyExchangeRate($currency);
    $amountUsd = $amount * $exchangeRate;
    
    $donationData = [
        'donor_name' => $customer['name'],
        'email' => $customer['email'],
        'phone' => $customer['metadata']['phone'] ?? '',
        'amount' => $amount,
        'currency' => $currency,
        'amount_usd' => $amountUsd,
        'is_monthly' => true,
        'is_dedicated' => $subscription['metadata']['is_dedicated'] === 'true',
        'comment' => $subscription['metadata']['comment'] ?? '',
        'country' => $customer['metadata']['country'] ?? 'Unknown',
        'city' => $customer['metadata']['city'] ?? '',
        'payment_method' => 'card',
        'transaction_id' => $invoice['payment_intent'],
        'stripe_subscription_id' => $subscription['id']
    ];
    
    $donationId = processDonation($donationData);
    
    if ($donationId) {
        sendDonationReceipt($donationId);
        error_log("Don mensuel traité: ID $donationId, Montant: $amount $currency");
    }
}

function handleCancelledSubscription($subscription, $pdo) {
    // Marquer l'abonnement comme annulé dans la base de données
    $stmt = $pdo->prepare("
        UPDATE monthly_subscriptions 
        SET status = 'cancelled', updated_at = NOW() 
        WHERE stripe_subscription_id = ?
    ");
    $stmt->execute([$subscription['id']]);
    
    error_log("Abonnement annulé: " . $subscription['id']);
}
?>