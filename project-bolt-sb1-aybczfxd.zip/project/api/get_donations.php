<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once '../config/database.php';
require_once '../includes/functions.php';

$offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 8;

$stmt = $pdo->prepare("
    SELECT 
        donor_name,
        amount,
        currency,
        is_monthly,
        country,
        city,
        created_at,
        CASE 
            WHEN country = 'France' THEN '🇫🇷'
            WHEN country = 'United States' THEN '🇺🇸'
            WHEN country = 'United Kingdom' THEN '🇬🇧'
            WHEN country = 'Germany' THEN '🇩🇪'
            WHEN country = 'Spain' THEN '🇪🇸'
            WHEN country = 'Italy' THEN '🇮🇹'
            WHEN country = 'Morocco' THEN '🇲🇦'
            WHEN country = 'Algeria' THEN '🇩🇿'
            WHEN country = 'Tunisia' THEN '🇹🇳'
            ELSE '🌍'
        END as country_flag
    FROM donations 
    WHERE status = 'completed'
    ORDER BY created_at DESC 
    LIMIT ? OFFSET ?
");

$stmt->execute([$limit, $offset]);
$donations = $stmt->fetchAll();

foreach ($donations as &$donation) {
    $donation['amount_display'] = formatCurrency($donation['amount'], $donation['currency']);
    $donation['donation_type'] = $donation['is_monthly'] ? 'a fait son don régulier' : 'a fait un don unique';
    $donation['location'] = $donation['city'] ? $donation['city'] . ', ' . $donation['country'] : $donation['country'];
}

echo json_encode($donations);
?>