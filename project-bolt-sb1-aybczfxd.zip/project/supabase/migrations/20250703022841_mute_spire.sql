-- Script d'initialisation pour Railway.app
-- Exécutez ce script dans la console Query de votre base MySQL Railway

-- Créer la base de données si elle n'existe pas
CREATE DATABASE IF NOT EXISTS railway CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE railway;

-- Table des dons
CREATE TABLE IF NOT EXISTS donations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    donor_name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(50),
    amount DECIMAL(10,2) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'EUR',
    amount_usd DECIMAL(10,2) NOT NULL,
    is_monthly BOOLEAN DEFAULT FALSE,
    is_dedicated BOOLEAN DEFAULT FALSE,
    comment TEXT,
    country VARCHAR(100),
    city VARCHAR(100),
    payment_method VARCHAR(50) DEFAULT 'card',
    transaction_id VARCHAR(255) UNIQUE,
    stripe_payment_intent_id VARCHAR(255),
    stripe_subscription_id VARCHAR(255),
    status ENUM('pending', 'completed', 'failed', 'refunded') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_status (status),
    INDEX idx_created_at (created_at),
    INDEX idx_country (country),
    INDEX idx_currency (currency),
    INDEX idx_email (email)
);

-- Table des statistiques de campagne
CREATE TABLE IF NOT EXISTS campaign_stats (
    id INT AUTO_INCREMENT PRIMARY KEY,
    total_raised_usd DECIMAL(12,2) DEFAULT 0,
    total_donations INT DEFAULT 0,
    unique_donors INT DEFAULT 0,
    countries_count INT DEFAULT 0,
    families_helped INT DEFAULT 0,
    meals_provided INT DEFAULT 0,
    goal_amount_usd DECIMAL(12,2) DEFAULT 1500000,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insérer les statistiques initiales
INSERT INTO campaign_stats (
    total_raised_usd, 
    total_donations, 
    unique_donors, 
    countries_count, 
    families_helped, 
    meals_provided
) VALUES (
    111161.82, 
    1247, 
    892, 
    23, 
    333485, 
    1111615
) ON DUPLICATE KEY UPDATE id=id;

-- Données d'exemple pour les dons récents
INSERT INTO donations (donor_name, email, amount, currency, amount_usd, country, city, status, created_at) VALUES
('Diane B.', 'diane.b@example.com', 54.10, 'USD', 54.10, 'United States', 'Chesnee', 'completed', NOW() - INTERVAL 1 HOUR),
('Hakim C.', 'hakim.c@example.com', 21.90, 'USD', 21.90, 'United States', 'Mission', 'completed', NOW() - INTERVAL 2 HOUR),
('Alu A.', 'alu.a@example.com', 9.00, 'GBP', 11.25, 'United Kingdom', '', 'completed', NOW() - INTERVAL 3 HOUR),
('Mohammed K.', 'mohammed.k@example.com', 76846.00, 'TZS', 33.04, 'Tanzania', 'Dar es Salaam', 'completed', NOW() - INTERVAL 4 HOUR),
('Margaret F.', 'margaret.f@example.com', 21.90, 'USD', 21.90, 'United States', 'Portage', 'completed', NOW() - INTERVAL 5 HOUR),
('Mouad A.', 'mouad.a@example.com', 9.00, 'EUR', 9.90, 'Spain', '', 'completed', NOW() - INTERVAL 6 HOUR),
('Abdul K.', 'abdul.k@example.com', 22.00, 'GBP', 27.50, 'United Kingdom', 'Birmingham', 'completed', NOW() - INTERVAL 7 HOUR),
('Alina K.', 'alina.k@example.com', 54.10, 'USD', 54.10, 'United States', 'New York', 'completed', NOW() - INTERVAL 8 HOUR),
('Serafin C.', 'serafin.c@example.com', 11.10, 'USD', 11.10, 'United States', 'Boise', 'completed', NOW() - INTERVAL 9 HOUR),
('Odette S.', 'odette.s@example.com', 27.20, 'USD', 27.20, 'United States', 'Sacramento', 'completed', NOW() - INTERVAL 10 HOUR),
('Nora B.', 'nora.b@example.com', 22.00, 'EUR', 24.20, 'Germany', 'Stuttgart', 'completed', NOW() - INTERVAL 11 HOUR),
('Omowumi L.', 'omowumi.l@example.com', 22.00, 'GBP', 27.50, 'United Kingdom', 'Sutton', 'completed', NOW() - INTERVAL 12 HOUR)
ON DUPLICATE KEY UPDATE id=id;

-- Trigger pour mettre à jour les statistiques automatiquement
DELIMITER //

CREATE TRIGGER IF NOT EXISTS update_stats_after_donation_insert
AFTER INSERT ON donations
FOR EACH ROW
BEGIN
    IF NEW.status = 'completed' THEN
        UPDATE campaign_stats SET 
            total_raised_usd = (SELECT COALESCE(SUM(amount_usd), 0) FROM donations WHERE status = 'completed'),
            total_donations = (SELECT COUNT(*) FROM donations WHERE status = 'completed'),
            unique_donors = (SELECT COUNT(DISTINCT email) FROM donations WHERE status = 'completed'),
            countries_count = (SELECT COUNT(DISTINCT country) FROM donations WHERE status = 'completed'),
            families_helped = FLOOR((SELECT COALESCE(SUM(amount_usd), 0) FROM donations WHERE status = 'completed') * 3),
            meals_provided = FLOOR((SELECT COALESCE(SUM(amount_usd), 0) FROM donations WHERE status = 'completed') * 10);
    END IF;
END//

CREATE TRIGGER IF NOT EXISTS update_stats_after_donation_update
AFTER UPDATE ON donations
FOR EACH ROW
BEGIN
    UPDATE campaign_stats SET 
        total_raised_usd = (SELECT COALESCE(SUM(amount_usd), 0) FROM donations WHERE status = 'completed'),
        total_donations = (SELECT COUNT(*) FROM donations WHERE status = 'completed'),
        unique_donors = (SELECT COUNT(DISTINCT email) FROM donations WHERE status = 'completed'),
        countries_count = (SELECT COUNT(DISTINCT country) FROM donations WHERE status = 'completed'),
        families_helped = FLOOR((SELECT COALESCE(SUM(amount_usd), 0) FROM donations WHERE status = 'completed') * 3),
        meals_provided = FLOOR((SELECT COALESCE(SUM(amount_usd), 0) FROM donations WHERE status = 'completed') * 10);
END//

DELIMITER ;

-- Vérification finale
SELECT 'Base de données initialisée avec succès!' as message;
SELECT COUNT(*) as donations_count FROM donations;
SELECT * FROM campaign_stats;