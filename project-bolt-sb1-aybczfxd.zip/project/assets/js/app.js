// Global variables
let currentDonation = {
    amount: 0,
    currency: 'EUR',
    isMonthly: false,
    isDedicated: false,
    comment: '',
    personalDetails: {},
    paymentMethod: 'card'
};

let donationsOffset = 8;
let isLoading = false;

// Currency data
const currencies = [
    { code: 'EUR', symbol: '€', name: 'Euro' },
    { code: 'USD', symbol: '$', name: 'Dollar américain' },
    { code: 'GBP', symbol: '£', name: 'Livre sterling' },
    { code: 'CAD', symbol: 'C$', name: 'Dollar canadien' },
    { code: 'AUD', symbol: 'A$', name: 'Dollar australien' },
    { code: 'CHF', symbol: 'CHF', name: 'Franc suisse' },
    { code: 'SEK', symbol: 'kr', name: 'Couronne suédoise' },
    { code: 'NOK', symbol: 'kr', name: 'Couronne norvégienne' },
    { code: 'DKK', symbol: 'kr', name: 'Couronne danoise' },
    { code: 'JPY', symbol: '¥', name: 'Yen japonais' },
    { code: 'CNY', symbol: '¥', name: 'Yuan chinois' },
    { code: 'KRW', symbol: '₩', name: 'Won sud-coréen' },
    { code: 'SGD', symbol: 'S$', name: 'Dollar de Singapour' },
    { code: 'HKD', symbol: 'HK$', name: 'Dollar de Hong Kong' },
    { code: 'NZD', symbol: 'NZ$', name: 'Dollar néo-zélandais' },
    { code: 'MXN', symbol: '$', name: 'Peso mexicain' },
    { code: 'BRL', symbol: 'R$', name: 'Real brésilien' },
    { code: 'ARS', symbol: '$', name: 'Peso argentin' },
    { code: 'CLP', symbol: '$', name: 'Peso chilien' },
    { code: 'COP', symbol: '$', name: 'Peso colombien' },
    { code: 'PEN', symbol: 'S/', name: 'Sol péruvien' },
    { code: 'UYU', symbol: '$U', name: 'Peso uruguayen' },
    { code: 'ZAR', symbol: 'R', name: 'Rand sud-africain' },
    { code: 'EGP', symbol: '£', name: 'Livre égyptienne' },
    { code: 'MAD', symbol: 'DH', name: 'Dirham marocain' },
    { code: 'TND', symbol: 'DT', name: 'Dinar tunisien' },
    { code: 'DZD', symbol: 'DA', name: 'Dinar algérien' },
    { code: 'SAR', symbol: 'SR', name: 'Riyal saoudien' },
    { code: 'AED', symbol: 'AED', name: 'Dirham des Émirats' },
    { code: 'QAR', symbol: 'QR', name: 'Riyal qatarien' },
    { code: 'KWD', symbol: 'KD', name: 'Dinar koweïtien' },
    { code: 'BHD', symbol: 'BD', name: 'Dinar bahreïni' },
    { code: 'OMR', symbol: 'OMR', name: 'Rial omanais' },
    { code: 'JOD', symbol: 'JD', name: 'Dinar jordanien' },
    { code: 'LBP', symbol: 'LL', name: 'Livre libanaise' },
    { code: 'ILS', symbol: '₪', name: 'Shekel israélien' },
    { code: 'TRY', symbol: '₺', name: 'Livre turque' },
    { code: 'IRR', symbol: '﷼', name: 'Rial iranien' },
    { code: 'PKR', symbol: '₨', name: 'Roupie pakistanaise' },
    { code: 'INR', symbol: '₹', name: 'Roupie indienne' },
    { code: 'BDT', symbol: '৳', name: 'Taka bangladais' },
    { code: 'LKR', symbol: '₨', name: 'Roupie sri-lankaise' },
    { code: 'NPR', symbol: '₨', name: 'Roupie népalaise' },
    { code: 'AFN', symbol: '؋', name: 'Afghani afghan' },
    { code: 'MYR', symbol: 'RM', name: 'Ringgit malaisien' },
    { code: 'THB', symbol: '฿', name: 'Baht thaïlandais' },
    { code: 'IDR', symbol: 'Rp', name: 'Roupie indonésienne' },
    { code: 'PHP', symbol: '₱', name: 'Peso philippin' },
    { code: 'VND', symbol: '₫', name: 'Dong vietnamien' },
    { code: 'RUB', symbol: '₽', name: 'Rouble russe' },
    { code: 'UAH', symbol: '₴', name: 'Hryvnia ukrainienne' },
    { code: 'PLN', symbol: 'zł', name: 'Zloty polonais' },
    { code: 'CZK', symbol: 'Kč', name: 'Couronne tchèque' },
    { code: 'HUF', symbol: 'Ft', name: 'Forint hongrois' },
    { code: 'RON', symbol: 'lei', name: 'Leu roumain' },
    { code: 'BGN', symbol: 'лв', name: 'Lev bulgare' },
    { code: 'HRK', symbol: 'kn', name: 'Kuna croate' },
    { code: 'RSD', symbol: 'дин', name: 'Dinar serbe' },
    { code: 'BAM', symbol: 'KM', name: 'Mark convertible' },
    { code: 'MKD', symbol: 'ден', name: 'Denar macédonien' },
    { code: 'ALL', symbol: 'L', name: 'Lek albanais' },
    { code: 'NGN', symbol: '₦', name: 'Naira nigérian' },
    { code: 'GHS', symbol: '₵', name: 'Cedi ghanéen' },
    { code: 'KES', symbol: 'KSh', name: 'Shilling kenyan' },
    { code: 'UGX', symbol: 'USh', name: 'Shilling ougandais' },
    { code: 'TZS', symbol: 'TSh', name: 'Shilling tanzanien' },
    { code: 'ETB', symbol: 'Br', name: 'Birr éthiopien' },
    { code: 'XOF', symbol: 'CFA', name: 'Franc CFA (BCEAO)' },
    { code: 'XAF', symbol: 'FCFA', name: 'Franc CFA (BEAC)' },
    { code: 'MUR', symbol: '₨', name: 'Roupie mauricienne' },
    { code: 'SCR', symbol: '₨', name: 'Roupie seychelloise' }
];

const countryCodes = [
    { code: '+33', country: 'France', flag: '🇫🇷' },
    { code: '+1', country: 'États-Unis', flag: '🇺🇸' },
    { code: '+44', country: 'Royaume-Uni', flag: '🇬🇧' },
    { code: '+49', country: 'Allemagne', flag: '🇩🇪' },
    { code: '+34', country: 'Espagne', flag: '🇪🇸' },
    { code: '+39', country: 'Italie', flag: '🇮🇹' },
    { code: '+212', country: 'Maroc', flag: '🇲🇦' },
    { code: '+213', country: 'Algérie', flag: '🇩🇿' },
    { code: '+216', country: 'Tunisie', flag: '🇹🇳' },
    { code: '+966', country: 'Arabie Saoudite', flag: '🇸🇦' },
    { code: '+971', country: 'Émirats Arabes Unis', flag: '🇦🇪' },
    { code: '+974', country: 'Qatar', flag: '🇶🇦' },
    { code: '+965', country: 'Koweït', flag: '🇰🇼' },
    { code: '+973', country: 'Bahreïn', flag: '🇧🇭' },
    { code: '+968', country: 'Oman', flag: '🇴🇲' },
    { code: '+962', country: 'Jordanie', flag: '🇯🇴' },
    { code: '+961', country: 'Liban', flag: '🇱🇧' },
    { code: '+90', country: 'Turquie', flag: '🇹🇷' },
    { code: '+20', country: 'Égypte', flag: '🇪🇬' },
    { code: '+92', country: 'Pakistan', flag: '🇵🇰' },
    { code: '+91', country: 'Inde', flag: '🇮🇳' },
    { code: '+880', country: 'Bangladesh', flag: '🇧🇩' },
    { code: '+60', country: 'Malaisie', flag: '🇲🇾' },
    { code: '+62', country: 'Indonésie', flag: '🇮🇩' },
    { code: '+66', country: 'Thaïlande', flag: '🇹🇭' },
    { code: '+63', country: 'Philippines', flag: '🇵🇭' },
    { code: '+84', country: 'Vietnam', flag: '🇻🇳' },
    { code: '+86', country: 'Chine', flag: '🇨🇳' },
    { code: '+81', country: 'Japon', flag: '🇯🇵' },
    { code: '+82', country: 'Corée du Sud', flag: '🇰🇷' },
    { code: '+65', country: 'Singapour', flag: '🇸🇬' },
    { code: '+852', country: 'Hong Kong', flag: '🇭🇰' },
    { code: '+61', country: 'Australie', flag: '🇦🇺' },
    { code: '+64', country: 'Nouvelle-Zélande', flag: '🇳🇿' },
    { code: '+55', country: 'Brésil', flag: '🇧🇷' },
    { code: '+52', country: 'Mexique', flag: '🇲🇽' },
    { code: '+54', country: 'Argentine', flag: '🇦🇷' },
    { code: '+56', country: 'Chili', flag: '🇨🇱' },
    { code: '+57', country: 'Colombie', flag: '🇨🇴' },
    { code: '+27', country: 'Afrique du Sud', flag: '🇿🇦' },
    { code: '+234', country: 'Nigeria', flag: '🇳🇬' },
    { code: '+254', country: 'Kenya', flag: '🇰🇪' },
    { code: '+255', country: 'Tanzanie', flag: '🇹🇿' }
];

const oneTimeAmounts = [800, 400, 200, 85, 40, 20];
const monthlyAmounts = [130, 85, 40, 25, 15, 9];

// Utility functions
function getCurrencySymbol(code) {
    const currency = currencies.find(c => c.code === code);
    return currency ? currency.symbol : '€';
}

function formatCurrency(amount, currency = 'EUR') {
    const symbol = getCurrencySymbol(currency);
    return `${parseFloat(amount).toFixed(2)} ${symbol}`;
}

function showLoading(element) {
    element.classList.add('loading');
    const spinner = document.createElement('span');
    spinner.className = 'spinner';
    element.insertBefore(spinner, element.firstChild);
}

function hideLoading(element) {
    element.classList.remove('loading');
    const spinner = element.querySelector('.spinner');
    if (spinner) spinner.remove();
}

// Modal functions
function openDonationModal() {
    document.getElementById('donation-modal').classList.remove('hidden');
    initializeDonationModal();
    document.body.style.overflow = 'hidden';
}

function closeDonationModal() {
    document.getElementById('donation-modal').classList.add('hidden');
    document.body.style.overflow = 'auto';
}

function openPersonalDetailsModal() {
    document.getElementById('personal-details-modal').classList.remove('hidden');
    initializePersonalDetailsModal();
}

function closePersonalDetailsModal() {
    document.getElementById('personal-details-modal').classList.add('hidden');
}

function openPaymentModal() {
    document.getElementById('payment-modal').classList.remove('hidden');
    initializePaymentModal();
}

function closePaymentModal() {
    document.getElementById('payment-modal').classList.add('hidden');
}

function openThankYouModal() {
    document.getElementById('thank-you-modal').classList.remove('hidden');
    initializeThankYouModal();
}

function closeThankYouModal() {
    document.getElementById('thank-you-modal').classList.add('hidden');
    document.body.style.overflow = 'auto';
    // Reset donation data
    currentDonation = {
        amount: 0,
        currency: 'EUR',
        isMonthly: false,
        isDedicated: false,
        comment: '',
        personalDetails: {},
        paymentMethod: 'card'
    };
}

function openCookieModal() {
    document.getElementById('cookie-modal').classList.remove('hidden');
}

function closeCookieModal() {
    document.getElementById('cookie-modal').classList.add('hidden');
}

// Donation modal functions
function initializeDonationModal() {
    generateAmountButtons();
    generateCurrencyOptions();
    setDonationType('once');
}

function generateAmountButtons() {
    const container = document.getElementById('amount-buttons');
    const amounts = currentDonation.isMonthly ? monthlyAmounts : oneTimeAmounts;
    const symbol = getCurrencySymbol(currentDonation.currency);
    
    container.innerHTML = amounts.map(amount => `
        <button type="button" onclick="selectAmount(${amount})" 
                class="amount-btn py-3 px-2 text-sm font-medium rounded-lg border-2 transition-all border-gray-300 text-gray-700 hover:border-primary/50" 
                data-amount="${amount}">
            ${amount} ${symbol}
        </button>
    `).join('');
}

function generateCurrencyOptions() {
    const select = document.getElementById('currency-select');
    select.innerHTML = currencies.map(currency => `
        <option value="${currency.code}" ${currency.code === currentDonation.currency ? 'selected' : ''}>
            ${currency.name} (${currency.symbol})
        </option>
    `).join('');
    
    select.addEventListener('change', function() {
        currentDonation.currency = this.value;
        generateAmountButtons();
        updateCustomAmountPlaceholder();
    });
}

function setDonationType(type) {
    currentDonation.isMonthly = type === 'monthly';
    
    // Update button styles
    document.querySelectorAll('.donation-type-btn').forEach(btn => {
        if (btn.dataset.type === type) {
            btn.className = 'donation-type-btn flex-1 py-3 px-4 text-sm font-medium transition-colors bg-primary text-white';
        } else {
            btn.className = 'donation-type-btn flex-1 py-3 px-4 text-sm font-medium transition-colors bg-gray-100 text-gray-700 hover:bg-gray-200';
        }
    });
    
    generateAmountButtons();
}

function selectAmount(amount) {
    currentDonation.amount = amount;
    document.getElementById('custom-amount').value = '';
    
    // Update button styles
    document.querySelectorAll('.amount-btn').forEach(btn => {
        if (parseInt(btn.dataset.amount) === amount) {
            btn.className = 'amount-btn py-3 px-2 text-sm font-medium rounded-lg border-2 transition-all border-primary bg-primary/10 text-primary';
        } else {
            btn.className = 'amount-btn py-3 px-2 text-sm font-medium rounded-lg border-2 transition-all border-gray-300 text-gray-700 hover:border-primary/50';
        }
    });
}

function updateCustomAmountPlaceholder() {
    const symbol = getCurrencySymbol(currentDonation.currency);
    document.getElementById('custom-amount').placeholder = `Montant personnalisé en ${symbol}`;
}

// Personal details modal functions
function initializePersonalDetailsModal() {
    generateCountryCodeOptions();
    updateDonationSummary();
}

function generateCountryCodeOptions() {
    const select = document.getElementById('country-code');
    select.innerHTML = countryCodes.map(country => `
        <option value="${country.code}">
            ${country.flag} ${country.code}
        </option>
    `).join('');
}

function updateDonationSummary() {
    const amount = currentDonation.amount || parseFloat(document.getElementById('custom-amount').value) || 0;
    const symbol = getCurrencySymbol(currentDonation.currency);
    document.getElementById('donation-summary').innerHTML = `
        Vous faites un don de <span class="font-bold">${amount} ${symbol}</span>
    `;
}

// Payment modal functions
function initializePaymentModal() {
    updatePaymentTitle();
    updateFeesDescription();
    setPaymentMethod('card');
    setupCardFormatting();
}

function updatePaymentTitle() {
    const amount = currentDonation.amount;
    const symbol = getCurrencySymbol(currentDonation.currency);
    document.getElementById('payment-title').textContent = `Vous faites un don ${amount} ${symbol}`;
}

function updateFeesDescription() {
    const amount = currentDonation.amount;
    const symbol = getCurrencySymbol(currentDonation.currency);
    const fee = Math.round(amount * 0.029 * 100) / 100;
    
    document.getElementById('fees-description').innerHTML = `
        Souhaitez-vous couvrir les frais de transaction (${fee.toFixed(2)} ${symbol}) 
        afin que nous recevions 100% de votre don ?
    `;
    
    document.getElementById('cover-fees').addEventListener('change', function() {
        const totalElement = document.getElementById('total-amount');
        if (this.checked) {
            const total = amount + fee;
            totalElement.innerHTML = `Total: ${total.toFixed(2)} ${symbol}`;
            totalElement.classList.remove('hidden');
        } else {
            totalElement.classList.add('hidden');
        }
    });
}

function setPaymentMethod(method) {
    currentDonation.paymentMethod = method;
    
    // Update button styles
    document.querySelectorAll('.payment-method-btn').forEach(btn => {
        if (btn.dataset.method === method) {
            btn.className = btn.className.replace(/bg-gray-\d+.*?(?=\s|$)/g, 'bg-primary text-white');
        } else {
            btn.className = btn.className.replace(/bg-primary.*?(?=\s|$)/g, 'bg-gray-100 text-gray-700 hover:bg-gray-200');
        }
    });
    
    // Show/hide card details
    const cardDetails = document.getElementById('card-details');
    if (method === 'card') {
        cardDetails.style.display = 'block';
    } else {
        cardDetails.style.display = 'none';
    }
}

function setupCardFormatting() {
    const cardNumber = document.getElementById('card-number');
    const cardExpiry = document.getElementById('card-expiry');
    const cardCvc = document.getElementById('card-cvc');
    
    cardNumber.addEventListener('input', function() {
        let value = this.value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
        let formattedValue = value.match(/.{1,4}/g)?.join(' ') || value;
        this.value = formattedValue;
    });
    
    cardExpiry.addEventListener('input', function() {
        let value = this.value.replace(/\D/g, '');
        if (value.length >= 2) {
            value = value.substring(0, 2) + '/' + value.substring(2, 4);
        }
        this.value = value;
    });
    
    cardCvc.addEventListener('input', function() {
        this.value = this.value.replace(/\D/g, '').substring(0, 4);
    });
}

// Thank you modal functions
function initializeThankYouModal() {
    const amount = currentDonation.amount;
    const symbol = getCurrencySymbol(currentDonation.currency);
    document.getElementById('thank-you-amount').innerHTML = `
        Montant: <span class="font-bold text-primary">${amount} ${symbol}</span>
    `;
}

// Form submission handlers
document.getElementById('donation-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Get form data
    const customAmount = parseFloat(document.getElementById('custom-amount').value);
    if (customAmount > 0) {
        currentDonation.amount = customAmount;
    }
    
    currentDonation.isDedicated = document.getElementById('dedicated-donation').checked;
    currentDonation.comment = document.getElementById('donation-comment').value;
    
    if (currentDonation.amount > 0) {
        closeDonationModal();
        openPersonalDetailsModal();
    }
});

document.getElementById('personal-details-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Get personal details
    currentDonation.personalDetails = {
        firstName: document.getElementById('first-name').value,
        lastName: document.getElementById('last-name').value,
        email: document.getElementById('email').value,
        phone: document.getElementById('phone').value,
        countryCode: document.getElementById('country-code').value
    };
    
    closePersonalDetailsModal();
    openPaymentModal();
});

document.getElementById('payment-form').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const submitBtn = this.querySelector('button[type="submit"]');
    showLoading(submitBtn);
    
    try {
        // Prepare donation data
        const donationData = {
            ...currentDonation,
            ...currentDonation.personalDetails,
            coverFees: document.getElementById('cover-fees').checked
        };
        
        // Submit to API
        const response = await fetch('api/process_donation.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(donationData)
        });
        
        const result = await response.json();
        
        if (result.success) {
            closePaymentModal();
            openThankYouModal();
            // Refresh page data
            setTimeout(() => location.reload(), 3000);
        } else {
            throw new Error(result.error || 'Payment failed');
        }
    } catch (error) {
        console.error('Payment error:', error);
        alert('Erreur lors du traitement du paiement. Veuillez réessayer.');
    } finally {
        hideLoading(submitBtn);
    }
});

// FAQ functions
function toggleFAQ(button) {
    const content = button.nextElementSibling;
    const icon = button.querySelector('[data-lucide="chevron-down"]');
    
    if (content.classList.contains('hidden')) {
        content.classList.remove('hidden');
        content.classList.add('show');
        icon.style.transform = 'rotate(180deg)';
    } else {
        content.classList.add('hidden');
        content.classList.remove('show');
        icon.style.transform = 'rotate(0deg)';
    }
}

// Load more donations
async function loadMoreDonations() {
    if (isLoading) return;
    
    isLoading = true;
    const btn = document.getElementById('load-more-btn');
    showLoading(btn);
    
    try {
        const response = await fetch(`api/get_donations.php?offset=${donationsOffset}&limit=8`);
        const donations = await response.json();
        
        if (donations.length > 0) {
            const container = document.getElementById('recent-donations');
            donations.forEach(donation => {
                const donationElement = document.createElement('div');
                donationElement.className = 'donation-item p-3 sm:p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors duration-200';
                donationElement.innerHTML = `
                    <div class="flex items-center gap-2 mb-2">
                        <span class="text-xl sm:text-2xl">${donation.country_flag}</span>
                        <p class="font-medium text-gray-800 text-sm sm:text-base">
                            <span class="font-bold">${donation.amount_display}</span>
                        </p>
                    </div>
                    <p class="text-xs sm:text-sm text-gray-600 mb-1">
                        ${donation.donor_name} ${donation.donation_type}
                    </p>
                    <p class="text-xs text-gray-500">
                        ${donation.location}
                    </p>
                `;
                container.appendChild(donationElement);
            });
            
            donationsOffset += donations.length;
            
            if (donations.length < 8) {
                btn.style.display = 'none';
            }
        } else {
            btn.style.display = 'none';
        }
    } catch (error) {
        console.error('Error loading donations:', error);
    } finally {
        isLoading = false;
        hideLoading(btn);
    }
}

// Utility functions
function shareWebsite() {
    if (navigator.share) {
        navigator.share({
            title: 'Vous pouvez nourrir le peuple palestinien ❤️',
            text: 'Aidez-nous à apporter des repas chauds aux familles palestiniennes dans le besoin.',
            url: window.location.href,
        });
    } else {
        navigator.clipboard.writeText(window.location.href);
        alert('Lien copié dans le presse-papiers !');
    }
}

function changeLanguage(lang) {
    // Language switching logic would go here
    console.log('Changing language to:', lang);
}

function acceptAllCookies() {
    // Cookie acceptance logic
    localStorage.setItem('cookies-accepted', 'true');
    closeCookieModal();
}

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
    // Check if cookies modal should be shown
    if (!localStorage.getItem('cookies-accepted')) {
        setTimeout(() => openCookieModal(), 2000);
    }
    
    // Initialize Lucide icons
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
    
    // Add smooth scrolling
    document.documentElement.style.scrollBehavior = 'smooth';
    
    // Add intersection observer for animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Observe elements for animation
    document.querySelectorAll('.donation-item, .faq-item').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
});

// Handle window resize for responsive adjustments
window.addEventListener('resize', function() {
    // Adjust modal heights on mobile
    const modals = document.querySelectorAll('.modal > div');
    modals.forEach(modal => {
        if (window.innerHeight < 700) {
            modal.style.maxHeight = '90vh';
        } else {
            modal.style.maxHeight = '';
        }
    });
});

// Service worker registration for PWA capabilities
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
        navigator.serviceWorker.register('/sw.js')
            .then(function(registration) {
                console.log('SW registered: ', registration);
            })
            .catch(function(registrationError) {
                console.log('SW registration failed: ', registrationError);
            });
    });
}