import React, { useState } from 'react';
import { X } from 'lucide-react';

interface PersonalDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onContinue: (details: PersonalDetails) => void;
  amount: number;
  currency: string;
}

export interface PersonalDetails {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  countryCode: string;
}

const countryCodes = [
  { code: '+33', country: 'France', flag: '🇫🇷' },
  { code: '+1', country: 'États-Unis', flag: '🇺🇸' },
  { code: '+44', country: 'Royaume-Uni', flag: '🇬🇧' },
  { code: '+49', country: 'Allemagne', flag: '🇩🇪' },
  { code: '+34', country: 'Espagne', flag: '🇪🇸' },
  { code: '+39', country: 'Italie', flag: '🇮🇹' },
  { code: '+212', country: 'Maroc', flag: '🇲🇦' },
  { code: '+213', country: 'Algérie', flag: '🇩🇿' },
  { code: '+216', country: 'Tunisie', flag: '🇹🇳' },
];

export const PersonalDetailsModal: React.FC<PersonalDetailsModalProps> = ({
  isOpen,
  onClose,
  onContinue,
  amount,
  currency
}) => {
  const [details, setDetails] = useState<PersonalDetails>({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    countryCode: '+33'
  });

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (details.firstName && details.lastName && details.email) {
      onContinue(details);
    }
  };

  const getCurrencySymbol = () => {
    const symbols: Record<string, string> = { 
      EUR: '€', USD: '$', GBP: '£', CAD: 'C$', AUD: 'A$', CHF: 'CHF', SEK: 'kr', NOK: 'kr', DKK: 'kr',
      JPY: '¥', CNY: '¥', KRW: '₩', SGD: 'S$', HKD: 'HK$', NZD: 'NZ$', MXN: '$', BRL: 'R$', ARS: '$',
      CLP: '$', COP: '$', PEN: 'S/', UYU: '$U', ZAR: 'R', EGP: '£', MAD: 'DH', TND: 'DT', DZD: 'DA',
      SAR: 'SR', AED: 'AED', QAR: 'QR', KWD: 'KD', BHD: 'BD', OMR: 'OMR', JOD: 'JD', LBP: 'LL',
      ILS: '₪', TRY: '₺', IRR: '﷼', PKR: '₨', INR: '₹', BDT: '৳', LKR: '₨', NPR: '₨', AFN: '؋',
      MYR: 'RM', THB: '฿', IDR: 'Rp', PHP: '₱', VND: '₫', RUB: '₽', UAH: '₴', PLN: 'zł', CZK: 'Kč',
      HUF: 'Ft', RON: 'lei', BGN: 'лв', HRK: 'kn', RSD: 'дин', BAM: 'KM', MKD: 'ден', ALL: 'L',
      NGN: '₦', GHS: '₵', KES: 'KSh', UGX: 'USh', TZS: 'TSh', ETB: 'Br', XOF: 'CFA', XAF: 'FCFA',
      MUR: '₨', SCR: '₨'
    };
    return symbols[currency] || '€';
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-md w-full">
        <div className="flex items-center justify-between p-6 border-b">
          <h2 className="text-xl font-semibold text-gray-800">Entrez vos coordonnées</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6">
          <div className="mb-4 p-3 bg-sky-50 border border-sky-200 rounded-lg">
            <p className="text-sm text-sky-800">
              Vous faites un don de <span className="font-bold">{amount} {getCurrencySymbol()}</span>
            </p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Prénom *
              </label>
              <input
                type="text"
                required
                value={details.firstName}
                onChange={(e) => setDetails(prev => ({ ...prev, firstName: e.target.value }))}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Nom *
              </label>
              <input
                type="text"
                required
                value={details.lastName}
                onChange={(e) => setDetails(prev => ({ ...prev, lastName: e.target.value }))}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Adresse e-mail *
              </label>
              <input
                type="email"
                required
                value={details.email}
                onChange={(e) => setDetails(prev => ({ ...prev, email: e.target.value }))}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Numéro de téléphone
              </label>
              <div className="flex gap-2">
                <select
                  value={details.countryCode}
                  onChange={(e) => setDetails(prev => ({ ...prev, countryCode: e.target.value }))}
                  className="p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
                >
                  {countryCodes.map((country) => (
                    <option key={country.code} value={country.code}>
                      {country.flag} {country.code}
                    </option>
                  ))}
                </select>
                <input
                  type="tel"
                  value={details.phone}
                  onChange={(e) => setDetails(prev => ({ ...prev, phone: e.target.value }))}
                  className="flex-1 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
                  placeholder="Numéro de téléphone"
                />
              </div>
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-sky-500 text-white py-3 px-4 rounded-lg font-medium hover:bg-sky-600 transition-colors mt-6"
          >
            Continuer
          </button>
        </form>
      </div>
    </div>
  );
};