import React from 'react';
import { Heart, CheckCircle, X } from 'lucide-react';

interface ThankYouModalProps {
  isOpen: boolean;
  onClose: () => void;
  amount: number;
  currency: string;
}

export const ThankYouModal: React.FC<ThankYouModalProps> = ({
  isOpen,
  onClose,
  amount,
  currency
}) => {
  if (!isOpen) return null;

  const getCurrencySymbol = () => {
    const symbols: Record<string, string> = { 
      EUR: '€', USD: '$', GBP: '£', CAD: 'C$', AUD: 'A$', CHF: 'CHF', SEK: 'kr', NOK: 'kr', DKK: 'kr',
      JPY: '¥', CNY: '¥', KRW: '₩', SGD: 'S$', HKD: 'HK$', NZD: 'NZ$', MXN: '$', BRL: 'R$', ARS: '$',
      CLP: '$', COP: '$', PEN: 'S/', UYU: '$U', ZAR: 'R', EGP: '£', MAD: 'DH', TND: 'DT', DZD: 'DA',
      SAR: 'SR', AED: 'AED', QAR: 'QR', KWD: 'KD', BHD: 'BD', OMR: 'OMR', JOD: 'JD', LBP: 'LL',
      ILS: '₪', TRY: '₺', IRR: '﷼', PKR: '₨', INR: '₹', BDT: '৳', LKR: '₨', NPR: '₨', AFN: '؋',
      MYR: 'RM', THB: '฿', IDR: 'Rp', PHP: '₱', VND: '₫', RUB: '₽', UAH: '₴', PLN: 'zł', CZK: 'Kč',
      HUF: 'Ft', RON: 'lei', BGN: 'лв', HRK: 'kn', RSD: 'дин', BAM: 'KM', MKD: 'ден', ALL: 'L',
      NGN: '₦', GHS: '₵', KES: 'KSh', UGX: 'USh', TZS: 'TSh', ETB: 'Br', XOF: 'CFA', XAF: 'FCFA',
      MUR: '₨', SCR: '₨'
    };
    return symbols[currency] || '€';
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-md w-full">
        <div className="flex items-center justify-between p-6 border-b">
          <div className="flex items-center gap-2">
            <CheckCircle className="text-sky-500" size={24} />
            <h2 className="text-xl font-semibold text-gray-800">Merci !</h2>
          </div>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X size={24} />
          </button>
        </div>

        <div className="p-6 text-center">
          <div className="mb-6">
            <Heart className="mx-auto text-sky-500 mb-4" size={48} />
            <h3 className="text-2xl font-bold text-gray-800 mb-2">
              Votre don a été traité avec succès !
            </h3>
            <p className="text-lg text-gray-600 mb-4">
              Montant: <span className="font-bold text-sky-600">
                {amount} {getCurrencySymbol()}
              </span>
            </p>
          </div>

          <div className="bg-sky-50 border border-sky-200 rounded-lg p-4 mb-6">
            <p className="text-sm text-sky-800 leading-relaxed">
              Grâce à votre générosité, des familles palestiniennes pourront avoir un repas chaud. 
              Votre geste de solidarité apporte de l'espoir et du réconfort à ceux qui en ont le plus besoin.
            </p>
          </div>

          <div className="text-sm text-gray-600 mb-6">
            <p className="mb-2">✅ Un reçu vous a été envoyé par e-mail</p>
            <p className="mb-2">✅ Votre don est déductible des impôts</p>
            <p>✅ 100% de votre don va directement à l'aide humanitaire</p>
          </div>

          <button
            onClick={onClose}
            className="w-full bg-sky-500 text-white py-3 px-4 rounded-lg font-medium hover:bg-sky-600 transition-colors"
          >
            Fermer
          </button>
        </div>
      </div>
    </div>
  );
};