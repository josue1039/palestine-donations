import React, { useState } from 'react';
import { X, Heart } from 'lucide-react';

interface DonationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onProceed: (amount: number, currency: string, isMonthly: boolean, isDedicated: boolean, comment: string) => void;
}

const currencies = [
  { code: 'EUR', symbol: '€', name: 'Euro' },
  { code: 'USD', symbol: '$', name: 'Dollar américain' },
  { code: 'GBP', symbol: '£', name: 'Livre sterling' },
  { code: 'CAD', symbol: 'C$', name: 'Dollar canadien' },
  { code: 'AUD', symbol: 'A$', name: 'Dollar australien' },
  { code: 'CHF', symbol: 'CHF', name: 'Franc suisse' },
  { code: 'SEK', symbol: 'kr', name: 'Couronne suédoise' },
  { code: 'NOK', symbol: 'kr', name: 'Couronne norvégienne' },
  { code: 'DKK', symbol: 'kr', name: 'Couronne danoise' },
  { code: 'JPY', symbol: '¥', name: 'Yen japonais' },
  { code: 'CNY', symbol: '¥', name: 'Yuan chinois' },
  { code: 'KRW', symbol: '₩', name: 'Won sud-coréen' },
  { code: 'SGD', symbol: 'S$', name: 'Dollar de Singapour' },
  { code: 'HKD', symbol: 'HK$', name: 'Dollar de Hong Kong' },
  { code: 'NZD', symbol: 'NZ$', name: 'Dollar néo-zélandais' },
  { code: 'MXN', symbol: '$', name: 'Peso mexicain' },
  { code: 'BRL', symbol: 'R$', name: 'Real brésilien' },
  { code: 'ARS', symbol: '$', name: 'Peso argentin' },
  { code: 'CLP', symbol: '$', name: 'Peso chilien' },
  { code: 'COP', symbol: '$', name: 'Peso colombien' },
  { code: 'PEN', symbol: 'S/', name: 'Sol péruvien' },
  { code: 'UYU', symbol: '$U', name: 'Peso uruguayen' },
  { code: 'ZAR', symbol: 'R', name: 'Rand sud-africain' },
  { code: 'EGP', symbol: '£', name: 'Livre égyptienne' },
  { code: 'MAD', symbol: 'DH', name: 'Dirham marocain' },
  { code: 'TND', symbol: 'DT', name: 'Dinar tunisien' },
  { code: 'DZD', symbol: 'DA', name: 'Dinar algérien' },
  { code: 'SAR', symbol: 'SR', name: 'Riyal saoudien' },
  { code: 'AED', symbol: 'AED', name: 'Dirham des Émirats' },
  { code: 'QAR', symbol: 'QR', name: 'Riyal qatarien' },
  { code: 'KWD', symbol: 'KD', name: 'Dinar koweïtien' },
  { code: 'BHD', symbol: 'BD', name: 'Dinar bahreïni' },
  { code: 'OMR', symbol: 'OMR', name: 'Rial omanais' },
  { code: 'JOD', symbol: 'JD', name: 'Dinar jordanien' },
  { code: 'LBP', symbol: 'LL', name: 'Livre libanaise' },
  { code: 'ILS', symbol: '₪', name: 'Shekel israélien' },
  { code: 'TRY', symbol: '₺', name: 'Livre turque' },
  { code: 'IRR', symbol: '﷼', name: 'Rial iranien' },
  { code: 'PKR', symbol: '₨', name: 'Roupie pakistanaise' },
  { code: 'INR', symbol: '₹', name: 'Roupie indienne' },
  { code: 'BDT', symbol: '৳', name: 'Taka bangladais' },
  { code: 'LKR', symbol: '₨', name: 'Roupie sri-lankaise' },
  { code: 'NPR', symbol: '₨', name: 'Roupie népalaise' },
  { code: 'AFN', symbol: '؋', name: 'Afghani afghan' },
  { code: 'MYR', symbol: 'RM', name: 'Ringgit malaisien' },
  { code: 'THB', symbol: '฿', name: 'Baht thaïlandais' },
  { code: 'IDR', symbol: 'Rp', name: 'Roupie indonésienne' },
  { code: 'PHP', symbol: '₱', name: 'Peso philippin' },
  { code: 'VND', symbol: '₫', name: 'Dong vietnamien' },
  { code: 'RUB', symbol: '₽', name: 'Rouble russe' },
  { code: 'UAH', symbol: '₴', name: 'Hryvnia ukrainienne' },
  { code: 'PLN', symbol: 'zł', name: 'Zloty polonais' },
  { code: 'CZK', symbol: 'Kč', name: 'Couronne tchèque' },
  { code: 'HUF', symbol: 'Ft', name: 'Forint hongrois' },
  { code: 'RON', symbol: 'lei', name: 'Leu roumain' },
  { code: 'BGN', symbol: 'лв', name: 'Lev bulgare' },
  { code: 'HRK', symbol: 'kn', name: 'Kuna croate' },
  { code: 'RSD', symbol: 'дин', name: 'Dinar serbe' },
  { code: 'BAM', symbol: 'KM', name: 'Mark convertible' },
  { code: 'MKD', symbol: 'ден', name: 'Denar macédonien' },
  { code: 'ALL', symbol: 'L', name: 'Lek albanais' },
  { code: 'NGN', symbol: '₦', name: 'Naira nigérian' },
  { code: 'GHS', symbol: '₵', name: 'Cedi ghanéen' },
  { code: 'KES', symbol: 'KSh', name: 'Shilling kenyan' },
  { code: 'UGX', symbol: 'USh', name: 'Shilling ougandais' },
  { code: 'TZS', symbol: 'TSh', name: 'Shilling tanzanien' },
  { code: 'ETB', symbol: 'Br', name: 'Birr éthiopien' },
  { code: 'XOF', symbol: 'CFA', name: 'Franc CFA (BCEAO)' },
  { code: 'XAF', symbol: 'FCFA', name: 'Franc CFA (BEAC)' },
  { code: 'MUR', symbol: '₨', name: 'Roupie mauricienne' },
  { code: 'SCR', symbol: '₨', name: 'Roupie seychelloise' }
];

const oneTimeAmounts = [800, 400, 200, 85, 40, 20];
const monthlyAmounts = [130, 85, 40, 25, 15, 9];

export const DonationModal: React.FC<DonationModalProps> = ({ isOpen, onClose, onProceed }) => {
  const [isMonthly, setIsMonthly] = useState(false);
  const [selectedAmount, setSelectedAmount] = useState<number | null>(null);
  const [customAmount, setCustomAmount] = useState('');
  const [currency, setCurrency] = useState('EUR');
  const [isDedicated, setIsDedicated] = useState(false);
  const [comment, setComment] = useState('');

  if (!isOpen) return null;

  const handleProceed = () => {
    const amount = selectedAmount || parseFloat(customAmount);
    if (amount > 0) {
      onProceed(amount, currency, isMonthly, isDedicated, comment);
    }
  };

  const getCurrentAmounts = () => isMonthly ? monthlyAmounts : oneTimeAmounts;
  const getCurrentSymbol = () => currencies.find(c => c.code === currency)?.symbol || '€';

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b">
          <h2 className="text-xl font-semibold text-gray-800">Don sécurisé</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X size={24} />
          </button>
        </div>

        <div className="p-6">
          <p className="text-sm text-gray-600 mb-6">Le moyen le plus efficace de soutenir la cause</p>

          <div className="mb-6">
            <div className="flex border rounded-lg overflow-hidden mb-4">
              <button
                onClick={() => setIsMonthly(false)}
                className={`flex-1 py-3 px-4 text-sm font-medium transition-colors ${
                  !isMonthly 
                    ? 'bg-sky-500 text-white' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                Donner une fois
              </button>
              <button
                onClick={() => setIsMonthly(true)}
                className={`flex-1 py-3 px-4 text-sm font-medium transition-colors ${
                  isMonthly 
                    ? 'bg-sky-500 text-white' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                Mensuel
              </button>
            </div>

            <div className="grid grid-cols-3 gap-3 mb-4">
              {getCurrentAmounts().map((amount) => (
                <button
                  key={amount}
                  onClick={() => {
                    setSelectedAmount(amount);
                    setCustomAmount('');
                  }}
                  className={`py-3 px-2 text-sm font-medium rounded-lg border-2 transition-all ${
                    selectedAmount === amount
                      ? 'border-sky-500 bg-sky-50 text-sky-600'
                      : 'border-gray-300 text-gray-700 hover:border-sky-300'
                  }`}
                >
                  {amount} {getCurrentSymbol()}
                </button>
              ))}
            </div>

            <div className="mb-4">
              <input
                type="number"
                placeholder={`Montant personnalisé en ${getCurrentSymbol()}`}
                value={customAmount}
                onChange={(e) => {
                  setCustomAmount(e.target.value);
                  setSelectedAmount(null);
                }}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
              />
            </div>

            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">Devise</label>
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
              >
                {currencies.map((curr) => (
                  <option key={curr.code} value={curr.code}>
                    {curr.name} ({curr.symbol})
                  </option>
                ))}
              </select>
            </div>

            <div className="mb-4">
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={isDedicated}
                  onChange={(e) => setIsDedicated(e.target.checked)}
                  className="w-4 h-4 text-sky-500 border-gray-300 rounded focus:ring-sky-500"
                />
                <span className="text-sm text-gray-700 flex items-center gap-1">
                  <Heart size={16} className="text-sky-500" />
                  Dédier ce don
                </span>
              </label>
            </div>

            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Ajouter un commentaire
              </label>
              <textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="Votre message (optionnel)"
                rows={3}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
              />
            </div>

            <button
              onClick={handleProceed}
              disabled={!selectedAmount && !customAmount}
              className="w-full bg-sky-500 text-white py-3 px-4 rounded-lg font-medium hover:bg-sky-600 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
            >
              Faire un don
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};