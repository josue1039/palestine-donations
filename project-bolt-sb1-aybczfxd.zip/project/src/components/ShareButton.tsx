import React from 'react';
import { Share2 } from 'lucide-react';

interface ShareButtonProps {
  onShare: () => void;
}

export const ShareButton: React.FC<ShareButtonProps> = ({ onShare }) => {
  return (
    <button
      onClick={onShare}
      className="inline-flex items-center gap-2 px-6 py-2 border-2 border-gray-800 text-gray-800 font-medium rounded-lg hover:bg-gray-800 hover:text-white transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-gray-800 focus:ring-offset-2"
    >
      <Share2 size={18} />
      Partager
    </button>
  );
};