import React from 'react';

interface ProgressBarProps {
  raised: number;
  goal: number;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({ raised, goal }) => {
  const percentage = Math.min((raised / goal) * 100, 100);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(amount).replace('$', '$ ');
  };

  return (
    <div className="w-full">
      <div className="mb-4">
        <p className="text-2xl font-bold text-gray-800 mb-1">
          {formatCurrency(raised)} collectés sur un objectif de {formatCurrency(goal)}
        </p>
      </div>
      
      <div className="relative w-full bg-gray-200 rounded-full h-4 overflow-hidden">
        <div 
          className="absolute top-0 left-0 h-full bg-gradient-to-r from-sky-400 to-sky-500 rounded-full transition-all duration-1000"
          style={{ width: `${percentage}%` }}
        >
          <div className="absolute inset-0 bg-white/20 animate-pulse rounded-full"></div>
        </div>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-xs font-semibold text-gray-700">
            {percentage.toFixed(1)}%
          </span>
        </div>
      </div>
    </div>
  );
};