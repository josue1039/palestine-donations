import React, { useState } from 'react';
import { X, CreditCard, Shield, Info } from 'lucide-react';
import { PersonalDetails } from './PersonalDetailsModal';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPayment: () => void;
  amount: number;
  currency: string;
  details: PersonalDetails;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  onClose,
  onPayment,
  amount,
  currency,
  details
}) => {
  const [coverFees, setCoverFees] = useState(false);
  const [cardNumber, setCardNumber] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvc, setCvc] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('card');

  if (!isOpen) return null;

  const getCurrencySymbol = () => {
    const symbols: Record<string, string> = { 
      EUR: '€', USD: '$', GBP: '£', CAD: 'C$', AUD: 'A$', CHF: 'CHF', SEK: 'kr', NOK: 'kr', DKK: 'kr',
      JPY: '¥', CNY: '¥', KRW: '₩', SGD: 'S$', HKD: 'HK$', NZD: 'NZ$', MXN: '$', BRL: 'R$', ARS: '$',
      CLP: '$', COP: '$', PEN: 'S/', UYU: '$U', ZAR: 'R', EGP: '£', MAD: 'DH', TND: 'DT', DZD: 'DA',
      SAR: 'SR', AED: 'AED', QAR: 'QR', KWD: 'KD', BHD: 'BD', OMR: 'OMR', JOD: 'JD', LBP: 'LL',
      ILS: '₪', TRY: '₺', IRR: '﷼', PKR: '₨', INR: '₹', BDT: '৳', LKR: '₨', NPR: '₨', AFN: '؋',
      MYR: 'RM', THB: '฿', IDR: 'Rp', PHP: '₱', VND: '₫', RUB: '₽', UAH: '₴', PLN: 'zł', CZK: 'Kč',
      HUF: 'Ft', RON: 'lei', BGN: 'лв', HRK: 'kn', RSD: 'дин', BAM: 'KM', MKD: 'ден', ALL: 'L',
      NGN: '₦', GHS: '₵', KES: 'KSh', UGX: 'USh', TZS: 'TSh', ETB: 'Br', XOF: 'CFA', XAF: 'FCFA',
      MUR: '₨', SCR: '₨'
    };
    return symbols[currency] || '€';
  };

  const transactionFee = Math.round(amount * 0.029 * 100) / 100; // 2.9% fee
  const totalAmount = coverFees ? amount + transactionFee : amount;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onPayment();
  };

  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = matches && matches[0] || '';
    const parts = [];
    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }
    if (parts.length) {
      return parts.join(' ');
    } else {
      return v;
    }
  };

  const formatExpiry = (value: string) => {
    const v = value.replace(/\D/g, '');
    if (v.length >= 2) {
      return v.substring(0, 2) + '/' + v.substring(2, 4);
    }
    return v;
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b">
          <h2 className="text-xl font-semibold text-gray-800">
            Vous faites un don {amount} {getCurrencySymbol()}
          </h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6">
          <div className="mb-6 p-4 bg-sky-50 border border-sky-200 rounded-lg">
            <div className="flex items-start gap-3">
              <Info className="text-sky-600 mt-0.5" size={20} />
              <div>
                <label className="flex items-center gap-2 text-sm">
                  <input
                    type="checkbox"
                    checked={coverFees}
                    onChange={(e) => setCoverFees(e.target.checked)}
                    className="w-4 h-4 text-sky-500 border-gray-300 rounded focus:ring-sky-500"
                  />
                  <span className="font-medium">Couvrir les frais de transaction</span>
                </label>
                <p className="text-xs text-gray-600 mt-1">
                  Souhaitez-vous couvrir les frais de transaction ({transactionFee.toFixed(2)} {getCurrencySymbol()}) 
                  afin que nous recevions 100% de votre don ?
                </p>
                {coverFees && (
                  <p className="text-sm font-medium text-sky-800 mt-2">
                    Total: {totalAmount.toFixed(2)} {getCurrencySymbol()}
                  </p>
                )}
              </div>
            </div>
          </div>

          <div className="mb-6">
            <div className="flex border rounded-lg overflow-hidden mb-4">
              <button
                type="button"
                onClick={() => setPaymentMethod('card')}
                className={`flex-1 py-3 px-4 text-sm font-medium transition-colors flex items-center justify-center gap-2 ${
                  paymentMethod === 'card'
                    ? 'bg-sky-500 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <CreditCard size={16} />
                Carte de crédit
              </button>
              <button
                type="button"
                onClick={() => setPaymentMethod('paypal')}
                className={`flex-1 py-3 px-4 text-sm font-medium transition-colors ${
                  paymentMethod === 'paypal'
                    ? 'bg-sky-500 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                PayPal
              </button>
              <button
                type="button"
                onClick={() => setPaymentMethod('googlepay')}
                className={`flex-1 py-3 px-4 text-sm font-medium transition-colors ${
                  paymentMethod === 'googlepay'
                    ? 'bg-sky-500 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                Google Pay
              </button>
            </div>
          </div>

          {paymentMethod === 'card' && (
            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Numéro de carte
                </label>
                <input
                  type="text"
                  required
                  value={cardNumber}
                  onChange={(e) => setCardNumber(formatCardNumber(e.target.value))}
                  maxLength={19}
                  placeholder="1234 5678 9012 3456"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
                />
              </div>

              <div className="flex gap-4">
                <div className="flex-1">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Expiration
                  </label>
                  <input
                    type="text"
                    required
                    value={expiry}
                    onChange={(e) => setExpiry(formatExpiry(e.target.value))}
                    maxLength={5}
                    placeholder="MM/AA"
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
                  />
                </div>
                <div className="flex-1">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    CVC
                  </label>
                  <input
                    type="text"
                    required
                    value={cvc}
                    onChange={(e) => setCvc(e.target.value.replace(/\D/g, '').substring(0, 4))}
                    maxLength={4}
                    placeholder="123"
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
                  />
                </div>
              </div>
            </div>
          )}

          <button
            type="submit"
            className="w-full bg-sky-500 text-white py-3 px-4 rounded-lg font-medium hover:bg-sky-600 transition-colors flex items-center justify-center gap-2"
          >
            <Shield size={20} />
            Faire un don
          </button>

          <div className="mt-4 p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-2 text-xs text-gray-600">
              <Shield size={14} />
              <span>Paiement sécurisé avec cryptage SSL</span>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};