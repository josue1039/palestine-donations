import React, { useState } from 'react';
import { X, Cookie, Shield, BarChart3, Target, Settings } from 'lucide-react';

interface CookieModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface CookiePreferences {
  necessary: boolean;
  functional: boolean;
  performance: boolean;
  marketing: boolean;
}

export const CookieModal: React.FC<CookieModalProps> = ({ isOpen, onClose }) => {
  const [preferences, setPreferences] = useState<CookiePreferences>({
    necessary: true,
    functional: false,
    performance: false,
    marketing: false
  });

  const [showDetails, setShowDetails] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleAcceptAll = () => {
    setPreferences({
      necessary: true,
      functional: true,
      performance: true,
      marketing: true
    });
    onClose();
  };

  const handleConfirmPreferences = () => {
    // Save preferences logic here
    onClose();
  };

  const cookieCategories = [
    {
      id: 'necessary',
      title: 'Strictement nécessaire',
      icon: <Shield className="text-sky-600" size={20} />,
      description: 'Ces cookies sont nécessaires au fonctionnement du site web et ne peuvent pas être désactivés. Nous les utilisons pour améliorer notre service anti-fraude. Des cookies tiers sécurisés de nos prestataires de paiement sont également nécessaires au bon déroulement des dons.',
      alwaysActive: true
    },
    {
      id: 'functional',
      title: 'Cookies fonctionnels',
      icon: <Settings className="text-sky-600" size={20} />,
      description: 'Ces cookies sont utilisés pour comprendre comment les utilisateurs utilisent notre site et mémorisent vos paramètres et préférences pour améliorer votre prochaine visite. Si vous n\'autorisez pas ces cookies fonctionnels, certains ou tous ces services risquent de ne pas fonctionner correctement.',
      alwaysActive: false
    },
    {
      id: 'performance',
      title: 'Cookies de performance',
      icon: <BarChart3 className="text-sky-600" size={20} />,
      description: 'Ces cookies nous permettent de compter les visites et les sources de trafic afin de mesurer et d\'améliorer l\'efficacité de nos services. Ils nous aident à comprendre comment les visiteurs utilisent le site. Toutes les informations collectées par ces cookies sont agrégées et donc totalement anonymes.',
      alwaysActive: false
    },
    {
      id: 'marketing',
      title: 'Cookies marketing',
      icon: <Target className="text-sky-600" size={20} />,
      description: 'Ces cookies stockent des informations pour améliorer votre expérience. Ils vous fournissent des fonctionnalités aussi pertinentes que possible.',
      alwaysActive: false
    }
  ];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b">
          <div className="flex items-center gap-2">
            <Cookie className="text-orange-600" size={24} />
            <h2 className="text-xl font-semibold text-gray-800">Gérer les cookies</h2>
          </div>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X size={24} />
          </button>
        </div>

        <div className="p-6">
          <p className="text-sm text-gray-600 mb-6 leading-relaxed">
            Notre politique en matière de cookies s'applique à ce domaine de l'entité 1A Najam Relief - CB. 
            Nous utilisons des cookies pour prévenir la fraude, améliorer les fonctionnalités du site et vous offrir 
            une meilleure expérience utilisateur. En cliquant sur « Accepter tout », vous acceptez l'utilisation de ces cookies. 
            Vous pouvez également configurer vos préférences de confidentialité en refusant ou en acceptant les types de cookies listés ci-dessous.
          </p>

          <div className="space-y-4 mb-6">
            {cookieCategories.map((category) => (
              <div key={category.id} className="border border-gray-200 rounded-lg">
                <div className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {category.icon}
                      <div>
                        <h3 className="font-medium text-gray-800">{category.title}</h3>
                        {category.alwaysActive && (
                          <span className="text-xs text-sky-600 font-medium">Toujours actif</span>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => setShowDetails(showDetails === category.id ? null : category.id)}
                        className="text-sm text-sky-600 hover:text-sky-700"
                      >
                        Détails des cookies
                      </button>
                      
                      {!category.alwaysActive && (
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={preferences[category.id as keyof CookiePreferences]}
                            onChange={(e) => setPreferences(prev => ({
                              ...prev,
                              [category.id]: e.target.checked
                            }))}
                            className="sr-only peer"
                          />
                          <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-sky-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-sky-500"></div>
                        </label>
                      )}
                    </div>
                  </div>

                  {showDetails === category.id && (
                    <div className="mt-4 pt-4 border-t border-gray-200">
                      <p className="text-sm text-gray-600 leading-relaxed">
                        {category.description}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          <div className="flex gap-4">
            <button
              onClick={handleConfirmPreferences}
              className="flex-1 bg-gray-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-gray-700 transition-colors"
            >
              Confirmer mes préférences
            </button>
            <button
              onClick={handleAcceptAll}
              className="flex-1 bg-sky-500 text-white py-3 px-4 rounded-lg font-medium hover:bg-sky-600 transition-colors"
            >
              Accepter tout
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};