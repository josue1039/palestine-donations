import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Shield, FileText, RotateCcw } from 'lucide-react';

interface FAQItem {
  id: string;
  question: string;
  answer: string;
  icon: React.ReactNode;
}

const faqItems: FAQItem[] = [
  {
    id: 'security',
    question: 'Mon don est-il sécurisé ?',
    answer: `Oui, nous utilisons la technologie SSL standard du secteur pour assurer la sécurité de vos informations.

Nous travaillons en partenariat avec Stripe, le processeur de paiement établi du secteur, auquel font confiance certaines des plus grandes entreprises mondiales.

Vos informations financières sensibles ne transitent jamais par nos serveurs. Nous envoyons toutes les données directement aux serveurs de Stripe, conformes à la norme PCI, via SSL.`,
    icon: <Shield className="text-green-600" size={20} />
  },
  {
    id: 'tax',
    question: 'Ce don est-il déductible des impôts ?',
    answer: `Votre don est déductible des impôts conformément à votre réglementation locale, car nous sommes une organisation exonérée d'impôt.

Nous vous enverrons un reçu de don par courriel. Veuillez le conserver, car il constitue votre preuve officielle de déduction fiscale pour ce don.`,
    icon: <FileText className="text-blue-600" size={20} />
  },
  {
    id: 'cancel',
    question: 'Puis-je annuler mon don récurrent ?',
    answer: `Bien sûr. Vous gardez toujours le contrôle total de votre don récurrent et êtes libre de le modifier ou de l'annuler à tout moment.`,
    icon: <RotateCcw className="text-orange-600" size={20} />
  }
];

export const FAQ: React.FC = () => {
  const [openItems, setOpenItems] = useState<string[]>([]);

  const toggleItem = (id: string) => {
    setOpenItems(prev => 
      prev.includes(id) 
        ? prev.filter(item => item !== id)
        : [...prev, id]
    );
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      {faqItems.map((item, index) => (
        <div key={item.id} className={`${index !== 0 ? 'border-t border-gray-200' : ''}`}>
          <button
            onClick={() => toggleItem(item.id)}
            className="w-full p-6 text-left hover:bg-gray-50 transition-colors duration-200 flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              {item.icon}
              <span className="font-medium text-gray-800">{item.question}</span>
            </div>
            {openItems.includes(item.id) ? (
              <ChevronUp className="text-gray-500" size={20} />
            ) : (
              <ChevronDown className="text-gray-500" size={20} />
            )}
          </button>
          
          {openItems.includes(item.id) && (
            <div className="px-6 pb-6">
              <div className="pl-8">
                <div className="text-sm text-gray-600 leading-relaxed whitespace-pre-line">
                  {item.answer}
                </div>
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
};