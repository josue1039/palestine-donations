import React, { useState, useEffect } from 'react';

interface Donation {
  id: string;
  name: string;
  amount: string;
  type: string;
  location: string;
  country: string;
  flag: string;
}

const fakeDonations: Donation[] = [
  { id: '1', name: 'Diane B.', amount: '54,10 $', type: 'a fait un don unique', location: 'Chesnee', country: 'États-Unis', flag: '🇺🇸' },
  { id: '2', name: 'Hakim C.', amount: '21,90 $', type: 'a fait un don unique', location: 'Mission', country: 'États-Unis', flag: '🇺🇸' },
  { id: '3', name: 'Alu A.', amount: '9,00 £', type: 'a fait un don unique', location: '', country: 'Royaume-Uni', flag: '🇬🇧' },
  { id: '4', name: 'Mohammed K.', amount: '76 846,00 TZS', type: 'a fait un don unique', location: 'Dar es Salaam', country: 'Tanzanie', flag: '🇹🇿' },
  { id: '5', name: 'Margaret F.', amount: '21,90 $', type: 'a fait son don régulier et dédié', location: 'Portage', country: 'États-Unis', flag: '🇺🇸' },
  { id: '6', name: 'Mouad A.', amount: '9,00 €', type: 'a commencé à faire des dons régulièrement', location: '', country: 'Espagne', flag: '🇪🇸' },
  { id: '7', name: 'Abdul K.', amount: '22,00 £', type: 'a fait un don unique', location: 'Birmingham', country: 'Royaume-Uni', flag: '🇬🇧' },
  { id: '8', name: 'Alina K.', amount: '54,10 $', type: 'a fait un don unique', location: 'New York', country: 'États-Unis', flag: '🇺🇸' },
  { id: '9', name: 'Serafin C.', amount: '11,10 $', type: 'a fait un don unique', location: 'Boise', country: 'États-Unis', flag: '🇺🇸' },
  { id: '10', name: 'Odette S.', amount: '27,20 $', type: 'a fait un don unique', location: 'Sacramento', country: 'États-Unis', flag: '🇺🇸' },
  { id: '11', name: 'Nora B.', amount: '22,00 €', type: 'a fait un don unique', location: 'Stuttgart', country: 'Allemagne', flag: '🇩🇪' },
  { id: '12', name: 'Omowumi L.', amount: '22,00 £', type: 'a fait un don unique', location: 'Sutton', country: 'Royaume-Uni', flag: '🇬🇧' },
];

export const RecentDonations: React.FC = () => {
  const [donations, setDonations] = useState<Donation[]>(fakeDonations);
  const [showAll, setShowAll] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      // Shuffle donations every 30 seconds to simulate real-time updates
      setDonations(prev => [...prev].sort(() => Math.random() - 0.5));
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  const displayedDonations = showAll ? donations : donations.slice(0, 8);

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <h3 className="text-xl font-semibold text-gray-800 mb-4">Dons récents</h3>
      
      <div className="space-y-4">
        {displayedDonations.map((donation) => (
          <div key={donation.id} className="flex items-start justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors duration-200">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-2xl">{donation.flag}</span>
                <p className="font-medium text-gray-800">
                  <span className="font-bold">{donation.amount}</span>
                </p>
              </div>
              <p className="text-sm text-gray-600 mb-1">
                {donation.name} {donation.type}
              </p>
              <p className="text-xs text-gray-500">
                {donation.location && `${donation.location}, `}{donation.country}
              </p>
            </div>
          </div>
        ))}
      </div>

      {!showAll && (
        <button
          onClick={() => setShowAll(true)}
          className="w-full mt-4 py-2 text-sm text-blue-600 hover:text-blue-700 font-medium transition-colors duration-200"
        >
          Charger plus
        </button>
      )}
    </div>
  );
};