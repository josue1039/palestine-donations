import React, { useState } from 'react';
import { Heart, Share2 } from 'lucide-react';
import { ShareButton } from './components/ShareButton';
import { ProgressBar } from './components/ProgressBar';
import { RecentDonations } from './components/RecentDonations';
import { DonationModal } from './components/DonationModal';
import { PersonalDetailsModal, PersonalDetails } from './components/PersonalDetailsModal';
import { PaymentModal } from './components/PaymentModal';
import { ThankYouModal } from './components/ThankYouModal';
import { FAQ } from './components/FAQ';
import { CookieModal } from './components/CookieModal';

function App() {
  const [donationModalOpen, setDonationModalOpen] = useState(false);
  const [personalDetailsModalOpen, setPersonalDetailsModalOpen] = useState(false);
  const [paymentModalOpen, setPaymentModalOpen] = useState(false);
  const [thankYouModalOpen, setThankYouModalOpen] = useState(false);
  const [cookieModalOpen, setCookieModalOpen] = useState(false);
  
  const [donationData, setDonationData] = useState({
    amount: 0,
    currency: 'EUR',
    isMonthly: false,
    isDedicated: false,
    comment: ''
  });
  
  const [personalDetails, setPersonalDetails] = useState<PersonalDetails>({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    countryCode: '+33'
  });

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Vous pouvez nourrir le peuple palestinien ❤️',
        text: 'Aidez-nous à apporter des repas chauds aux familles palestiniennes dans le besoin.',
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert('Lien copié dans le presse-papiers !');
    }
  };

  const handleDonationProceed = (amount: number, currency: string, isMonthly: boolean, isDedicated: boolean, comment: string) => {
    setDonationData({ amount, currency, isMonthly, isDedicated, comment });
    setDonationModalOpen(false);
    setPersonalDetailsModalOpen(true);
  };

  const handlePersonalDetailsContinue = (details: PersonalDetails) => {
    setPersonalDetails(details);
    setPersonalDetailsModalOpen(false);
    setPaymentModalOpen(true);
  };

  const handlePayment = () => {
    setPaymentModalOpen(false);
    setThankYouModalOpen(true);
  };

  const handleThankYouClose = () => {
    setThankYouModalOpen(false);
    // Reset all data
    setDonationData({ amount: 0, currency: 'EUR', isMonthly: false, isDedicated: false, comment: '' });
    setPersonalDetails({ firstName: '', lastName: '', email: '', phone: '', countryCode: '+33' });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center">
            <img 
              src="/photo_2025-07-02_21-18-03.jpg" 
              alt="Logo Najam Relief"
              className="h-12 w-auto"
            />
          </div>
          <ShareButton onShare={handleShare} />
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-800 mb-6 flex items-center justify-center gap-2">
            Vous pouvez nourrir le peuple palestinien <Heart className="text-sky-500" size={32} />
          </h1>
          
          <div className="mb-8">
            <ProgressBar raised={111161.82} goal={1500000} />
          </div>

          {/* Hero Image */}
          <div className="mb-8">
            <img 
              src="/don1.jpg" 
              alt="Enfant palestinien cherchant de la nourriture"
              className="w-full max-w-2xl mx-auto rounded-lg shadow-lg"
            />
          </div>

          <div className="max-w-3xl mx-auto text-lg text-gray-700 leading-relaxed space-y-4">
            <p>
              <strong>Vous pouvez être la raison pour laquelle une famille en Palestine a un repas chaud.</strong> 
              Le réconfort, la nourriture et l'espoir peuvent atteindre ceux qui luttent dans une crise grâce à des actes de générosité et de compassion.
            </p>
            <p>
              Votre générosité compte, chaque repas que vous donnez apporte du soulagement et restaure la dignité. 
              C'est plus qu'un repas, c'est un message d'amour, d'espoir et de solidarité.
            </p>
            <p className="text-xl font-semibold text-sky-600">
              Donnez maintenant, car votre gentillesse peut changer des vies. 🌙 🍽️
            </p>
          </div>

          {/* Donation Button */}
          <div className="mt-8">
            <button
              onClick={() => setDonationModalOpen(true)}
              className="bg-sky-500 text-white px-8 py-4 text-xl font-bold rounded-lg hover:bg-sky-600 transform hover:scale-105 transition-all duration-200 shadow-lg"
            >
              FAIRE UN DON
            </button>
          </div>
        </div>

        {/* Recent Donations */}
        <div className="mb-8">
          <RecentDonations />
        </div>

        {/* FAQ Section */}
        <div className="mb-8">
          <FAQ />
        </div>

        {/* Footer Links */}
        <div className="text-center space-y-2 text-sm text-gray-600">
          <button
            onClick={() => setCookieModalOpen(true)}
            className="hover:text-gray-800 transition-colors underline"
          >
            Politique relative aux cookies
          </button>
        </div>
      </div>

      {/* Modals */}
      <DonationModal
        isOpen={donationModalOpen}
        onClose={() => setDonationModalOpen(false)}
        onProceed={handleDonationProceed}
      />

      <PersonalDetailsModal
        isOpen={personalDetailsModalOpen}
        onClose={() => setPersonalDetailsModalOpen(false)}
        onContinue={handlePersonalDetailsContinue}
        amount={donationData.amount}
        currency={donationData.currency}
      />

      <PaymentModal
        isOpen={paymentModalOpen}
        onClose={() => setPaymentModalOpen(false)}
        onPayment={handlePayment}
        amount={donationData.amount}
        currency={donationData.currency}
        details={personalDetails}
      />

      <ThankYouModal
        isOpen={thankYouModalOpen}
        onClose={handleThankYouClose}
        amount={donationData.amount}
        currency={donationData.currency}
      />

      <CookieModal
        isOpen={cookieModalOpen}
        onClose={() => setCookieModalOpen(false)}
      />
    </div>
  );
}

export default App;