<?php
// Configuration Stripe
require_once __DIR__ . '/../vendor/autoload.php';

// Clés Stripe - Remplacez par vos vraies clés
define('STRIPE_PUBLISHABLE_KEY', $_ENV['STRIPE_PUBLISHABLE_KEY'] ?? 'pk_test_...');
define('STRIPE_SECRET_KEY', $_ENV['STRIPE_SECRET_KEY'] ?? 'sk_test_...');
define('STRIPE_WEBHOOK_SECRET', $_ENV['STRIPE_WEBHOOK_SECRET'] ?? 'whsec_...');

// Initialiser Stripe avec votre clé secrète
\Stripe\Stripe::setApiKey(STRIPE_SECRET_KEY);

// Vérifier que les clés sont configurées
if (STRIPE_SECRET_KEY === 'sk_test_...' || STRIPE_PUBLISHABLE_KEY === 'pk_test_...') {
    error_log('ATTENTION: Clés Stripe par défaut détectées. Veuillez configurer vos vraies clés.');
}
?>