<?php
// Configuration pour hébergement gratuit avec base de données

// Détection automatique de l'environnement
if (isset($_ENV['DATABASE_URL'])) {
    // Heroku/Railway style
    $url = parse_url($_ENV['DATABASE_URL']);
    $host = $url['host'];
    $dbname = ltrim($url['path'], '/');
    $username = $url['user'];
    $password = $url['pass'];
    $port = $url['port'] ?? 3306;
} elseif (isset($_ENV['DB_HOST'])) {
    // Variables d'environnement séparées
    $host = $_ENV['DB_HOST'];
    $dbname = $_ENV['DB_NAME'];
    $username = $_ENV['DB_USER'];
    $password = $_ENV['DB_PASS'];
    $port = $_ENV['DB_PORT'] ?? 3306;
} else {
    // Configuration locale pour développement
    $host = 'localhost';
    $dbname = 'donation_platform';
    $username = 'root';
    $password = '';
    $port = 3306;
}

try {
    $dsn = "mysql:host=$host;port=$port;dbname=$dbname;charset=utf8mb4";
    $pdo = new PDO($dsn, $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
        PDO::MYSQL_ATTR_SSL_VERIFY_SERVER_CERT => false
    ]);
} catch(PDOException $e) {
    // Fallback vers SQLite pour les hébergements très limités
    try {
        $pdo = new PDO('sqlite:' . __DIR__ . '/../data/donations.db');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        
        // Créer les tables SQLite si nécessaire
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS donations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                donor_name TEXT NOT NULL,
                email TEXT NOT NULL,
                phone TEXT,
                amount REAL NOT NULL,
                currency TEXT NOT NULL DEFAULT 'EUR',
                amount_usd REAL NOT NULL,
                is_monthly INTEGER DEFAULT 0,
                is_dedicated INTEGER DEFAULT 0,
                comment TEXT,
                country TEXT,
                city TEXT,
                payment_method TEXT DEFAULT 'card',
                transaction_id TEXT UNIQUE,
                status TEXT DEFAULT 'pending',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ");
        
    } catch(PDOException $e2) {
        die("Erreur de connexion à la base de données: " . $e2->getMessage());
    }
}
?>