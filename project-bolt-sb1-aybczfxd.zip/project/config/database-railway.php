<?php
// Configuration spécifique pour Railway.app

// Railway fournit automatiquement ces variables d'environnement
$host = $_ENV['MYSQLHOST'] ?? $_ENV['DB_HOST'] ?? 'localhost';
$port = $_ENV['MYSQLPORT'] ?? $_ENV['DB_PORT'] ?? 3306;
$dbname = $_ENV['MYSQLDATABASE'] ?? $_ENV['DB_NAME'] ?? 'railway';
$username = $_ENV['MYSQLUSER'] ?? $_ENV['DB_USER'] ?? 'root';
$password = $_ENV['MYSQLPASSWORD'] ?? $_ENV['DB_PASS'] ?? '';

// URL de connexion Railway (format alternatif)
if (isset($_ENV['DATABASE_URL'])) {
    $url = parse_url($_ENV['DATABASE_URL']);
    $host = $url['host'];
    $port = $url['port'] ?? 3306;
    $dbname = ltrim($url['path'], '/');
    $username = $url['user'];
    $password = $url['pass'];
}

try {
    $dsn = "mysql:host=$host;port=$port;dbname=$dbname;charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
        PDO::MYSQL_ATTR_SSL_VERIFY_SERVER_CERT => false,
        PDO::ATTR_TIMEOUT => 30
    ];
    
    $pdo = new PDO($dsn, $username, $password, $options);
    
    // Test de connexion
    $pdo->query('SELECT 1');
    
} catch(PDOException $e) {
    // Log l'erreur pour debugging
    error_log("Database connection error: " . $e->getMessage());
    
    // Message d'erreur user-friendly
    die("Erreur de connexion à la base de données. Veuillez vérifier la configuration.");
}

// Variables d'environnement pour Railway
$railway_config = [
    'environment' => $_ENV['RAILWAY_ENVIRONMENT'] ?? 'production',
    'service_name' => $_ENV['RAILWAY_SERVICE_NAME'] ?? 'donation-platform',
    'deployment_id' => $_ENV['RAILWAY_DEPLOYMENT_ID'] ?? 'unknown'
];

// Log des informations de déploiement
if ($railway_config['environment'] === 'production') {
    error_log("Railway deployment: " . $railway_config['deployment_id']);
}
?>